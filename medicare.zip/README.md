# Medicare Hospital Appointment and Patient Management System

A modular-monolith hospital application built with Java 25, Spring Boot 3, Maven, Spring Data JPA, Spring Security, JWT, MySQL, and a responsive HTML/CSS/vanilla-JavaScript frontend.

## Requirements

- JDK 25 or later
- Maven 3.9+
- MySQL 8+

## Run locally

1. Create a MySQL user/database, or use a local MySQL account with database-creation privileges. The default JDBC URL creates the `medicare` database if it does not exist.
2. Set the connection details and enable the development seed accounts. In PowerShell:

   ```powershell
   $env:DB_URL = "jdbc:mysql://localhost:3306/medicare?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC"
   $env:DB_USERNAME = "root"
   $env:DB_PASSWORD = "your-local-mysql-password"
   $env:SEED_ENABLED = "true"
   ```

   For a quick local smoke test without MySQL, use the H2 in-memory fallback:

   ```powershell
   $env:DB_DRIVER_CLASS_NAME = "org.h2.Driver"
   $env:DB_DIALECT = "org.hibernate.dialect.H2Dialect"
   $env:DB_URL = "jdbc:h2:mem:medicare;MODE=MySQL;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE"
   $env:DB_USERNAME = "sa"
   $env:DB_PASSWORD = ""
   $env:SEED_ENABLED = "true"
   ```

3. Set a private JWT signing secret (at least 32 bytes). The configured default is development-only:

   ```powershell
   $env:JWT_SECRET = "replace-this-with-a-private-random-secret-of-at-least-32-bytes"
   ```

4. Start the application:

   ```powershell
   mvn spring-boot:run
   ```

5. Open [http://localhost:8080](http://localhost:8080). OpenAPI documentation is at [http://localhost:8080/swagger-ui.html](http://localhost:8080/swagger-ui.html).

The frontend is served by Spring Boot and uses the same origin by default. To serve it elsewhere, set `FRONTEND_ORIGIN` to the exact frontend origin. Database schema updates are managed with Hibernate `ddl-auto=update` for local development. Use a reviewed migration tool and `DDL_AUTO=validate` in production.

Doctor consultation fees are entered and displayed in Indian rupees (INR).

### Development seed accounts

These intentionally fake accounts are seeded only when `SEED_ENABLED=true`; every account uses the same development-only password:

| Role | Email | Password |
|---|---|---|
| ADMIN | `admin@medicare.test` | `DemoPass123!` |
| RECEPTIONIST | `reception@medicare.test` | `DemoPass123!` |
| DOCTOR | `doctor.lee@medicare.test` | `DemoPass123!` |
| DOCTOR | `doctor.patel@medicare.test` | `DemoPass123!` |
| DOCTOR | `doctor.rao@medicare.test` | `DemoPass123!` |
| DOCTOR | `doctor.williams@medicare.test` | `DemoPass123!` |
| DOCTOR | `doctor.khan@medicare.test` | `DemoPass123!` |
| DOCTOR | `doctor.shah@medicare.test` | `DemoPass123!` |
| PATIENT | `patient.jordan@medicare.test` | `DemoPass123!` |
| PATIENT | `patient.taylor@medicare.test` | `DemoPass123!` |
| PATIENT | `patient.casey@medicare.test` | `DemoPass123!` |

The initializer is idempotent and creates sample departments, weekday doctor schedules, a confirmed future appointment, a completed sample consultation, a prescription, and notifications. Never enable seed accounts in production.

## Build and test

```powershell
mvn clean test
```

The Maven test starter and Spring Security test utilities are included. API endpoints can also be exercised via the OpenAPI UI or the example requests below. A configured MySQL instance is needed to start the full application.

## API overview

All authenticated requests use `Authorization: Bearer <token>`. Access is role-scoped. Paginated list endpoints return Spring Data page objects with `content`, `totalElements`, `totalPages`, `number`, and `size`.

| Module | Endpoints |
|---|---|
| Authentication | `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout`, `POST /api/auth/password-reset`, `POST /api/auth/password-reset/complete` |
| Users and patients | `GET/PUT /api/users/me`, `GET /api/users` (admin), `PATCH /api/users/{id}/status` (admin), `GET/PUT /api/patients/me`, `GET /api/patients` (receptionist/admin) |
| Doctors and departments | `GET /api/doctors?search=&departmentId=&page=&size=`, `GET /api/doctors/{id}`, `POST/PUT/DELETE /api/doctors`, `PUT /api/doctors/me`, `GET /api/departments`, `POST/PUT/DELETE /api/departments` |
| Availability | `GET /api/doctors/{id}/availability`, `GET /api/doctors/{id}/availability/slots?date=YYYY-MM-DD`, `POST/PUT/DELETE /api/doctors/{id}/availability/{availabilityId}` |
| Appointments | `POST /api/appointments`, `POST /api/appointments/for-patient`, `GET /api/appointments`, `GET /api/appointments/{id}`, `POST /api/appointments/{id}/cancel`, `/confirm`, `/reschedule`, `/check-in`, `/start`, `/complete`, `/no-show` |
| Clinical records | `POST /api/consultations`, `PUT /api/consultations/{id}`, `GET /api/consultations/{id}`, `GET /api/consultations/mine`, `GET /api/prescriptions/mine` |
| Notifications and dashboards | `GET /api/notifications`, `PATCH /api/notifications/{id}/read`, `GET /api/dashboard/{patient,doctor,receptionist,admin}` |

## Example requests

Register a patient:

```http
POST /api/auth/register
Content-Type: application/json

{"fullName":"Alex Morgan","email":"alex@example.test","password":"SecureDemo123","phone":"+1 555 010 4488"}
```

Example response (token shortened here for readability):

```json
{
  "token": "<signed-jwt>",
  "tokenType": "Bearer",
  "user": {
    "id": 21,
    "fullName": "Alex Morgan",
    "email": "alex@example.test",
    "phone": "+1 555 010 4488",
    "role": "PATIENT",
    "active": true
  }
}
```

Book a doctor slot using the time returned by the availability endpoint:

```http
POST /api/appointments
Authorization: Bearer <signed-jwt>
Content-Type: application/json

{"doctorId":1,"date":"2026-10-06","startTime":"09:00:00","reason":"Annual check-up","type":"IN_PERSON"}
```

Validation/conflict errors use a consistent shape:

```json
{"timestamp":"2026-10-05T10:00:00Z","status":409,"error":"Conflict","message":"This time slot has already been booked."}
```

## Security and operational notes

- Passwords use BCrypt; password hashes are never serialized to API responses.
- JWT expiry defaults to 24 hours. The client removes the token on logout; JWTs are otherwise stateless.
- Patient registration creates only `PATIENT` accounts. Admins create doctor profiles; staff accounts should be provisioned administratively.
- Appointment booking is validated and serialized per doctor in a database transaction; the backend checks schedule, slot alignment, break periods, past dates, doctor status, and overlapping active appointments.
- Consultation records are editable only by the assigned doctor until finalized. Receptionists cannot edit clinical records; patients see their own records only.
- Password reset endpoints establish expiring, one-time tokens and a mocked delivery boundary. No email provider is configured; provide a real delivery adapter before relying on password recovery outside local development.
- `SEED_ENABLED` defaults to `false`. Use fake development credentials only locally. Set a private `JWT_SECRET`, restrict CORS, configure database credentials through secrets, use TLS, and disable seed data for deployment.
