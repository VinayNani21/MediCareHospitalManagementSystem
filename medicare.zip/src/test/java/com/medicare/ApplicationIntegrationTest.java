package com.medicare;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.medicare.availability.DoctorAvailabilityRepository;
import com.medicare.doctor.DoctorRepository;
import com.medicare.patient.PatientRepository;
import com.medicare.user.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class ApplicationIntegrationTest {
    @Autowired MockMvc mvc;
    @Autowired ObjectMapper mapper;
    @Autowired DoctorRepository doctors;
    @Autowired DoctorAvailabilityRepository availability;
    @Autowired PatientRepository patients;
    @Autowired UserRepository users;

    @Test
    void seededLoginReturnsJwtAndNeverExposesPasswordHash() throws Exception {
        MvcResult result = mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(Map.of("email", "patient.jordan@medicare.test", "password", "DemoPass123!"))))
                .andExpect(status().isOk()).andExpect(jsonPath("$.token").isNotEmpty())
                .andExpect(jsonPath("$.user.role").value("PATIENT"))
                .andExpect(content().string(not(containsString("passwordHash")))).andReturn();
        String token = JsonPath.read(result.getResponse().getContentAsString(), "$.token");
        mvc.perform(get("/api/patients/me").header("Authorization", "Bearer " + token))
                .andExpect(status().isOk()).andExpect(jsonPath("$.medicalRecordNumber").isNotEmpty());
    }

    @Test
    void unauthenticatedPatientDataIsRejected() throws Exception {
        mvc.perform(get("/api/patients/me")).andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.status").value(401));
    }

    @Test
    void seedIncludesAdditionalDoctorsWithWeekdayAvailability() {
        assertTrue(doctors.count() >= 6);
        for (String email : java.util.List.of("doctor.rao@medicare.test", "doctor.williams@medicare.test",
                "doctor.khan@medicare.test", "doctor.shah@medicare.test")) {
            var user = users.findByEmailIgnoreCase(email).orElseThrow();
            var doctor = doctors.findByUserId(user.getId()).orElseThrow();
            assertEquals(5, availability.findByDoctorId(doctor.getId()).size());
        }
    }

    @Test
    void bookingEnforcesScheduleAndRejectsOverlappingSlot() throws Exception {
        String token = login("patient.jordan@medicare.test");
        var doctor = doctors.findByUserId(users.findByEmailIgnoreCase("doctor.lee@medicare.test").orElseThrow().getId()).orElseThrow();
        LocalDate date = LocalDate.now().plusDays(1);
        while (date.getDayOfWeek() == DayOfWeek.SATURDAY || date.getDayOfWeek() == DayOfWeek.SUNDAY) date = date.plusDays(1);
        String body = mapper.writeValueAsString(Map.of("doctorId", doctor.getId(), "date", date.toString(),
                "startTime", "09:00:00", "reason", "Automated integration test", "type", "ONLINE"));
        MvcResult booking = mvc.perform(post("/api/appointments").header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isCreated()).andExpect(jsonPath("$.status").value("REQUESTED")).andReturn();
        mvc.perform(post("/api/appointments").header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.message").value(containsString("already been booked")));
        long appointmentId = ((Number) JsonPath.read(booking.getResponse().getContentAsString(), "$.id")).longValue();
        String adminToken = login("admin@medicare.test");
        mvc.perform(post("/api/appointments/{id}/confirm", appointmentId).header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isOk()).andExpect(jsonPath("$.status").value("CONFIRMED"));
        mvc.perform(post("/api/appointments/{id}/check-in", appointmentId).header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isOk()).andExpect(jsonPath("$.status").value("CHECKED_IN"));
    }

    private String login(String email) throws Exception {
        MvcResult result = mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(Map.of("email", email, "password", "DemoPass123!"))))
                .andExpect(status().isOk()).andReturn();
        return JsonPath.read(result.getResponse().getContentAsString(), "$.token");
    }
}
