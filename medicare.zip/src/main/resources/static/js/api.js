(function () {
  const base = "/api";
  const tokenKey = "medicare.jwt";
  async function request(path, options = {}) {
    const headers = new Headers(options.headers || {});
    const token = localStorage.getItem(tokenKey);
    if (token) headers.set("Authorization", `Bearer ${token}`);
    if (options.body && !(options.body instanceof FormData)) headers.set("Content-Type", "application/json");
    let response;
    try {
      response = await fetch(`${base}${path}`, { ...options, headers });
    } catch {
      throw new Error("Unable to connect to Medicare. Check that the server is running.");
    }
    const body = response.status === 204 ? null : await response.json().catch(() => null);
    if (response.status === 401) {
      localStorage.removeItem(tokenKey);
      localStorage.removeItem("medicare.user");
      if (!location.pathname.endsWith("login.html")) location.href = "/login.html?expired=1";
      throw new Error(body?.message || "Your session has expired. Please log in again.");
    }
    if (!response.ok) throw new Error(body?.message || body?.error || `Request failed (${response.status}).`);
    return body;
  }
  const json = (method, body) => ({ method, body: JSON.stringify(body) });
  window.MedicareApi = {
    get: path => request(path),
    post: (path, body = {}) => request(path, json("POST", body)),
    put: (path, body) => request(path, json("PUT", body)),
    patch: (path, body) => request(path, json("PATCH", body)),
    delete: path => request(path, { method: "DELETE" }),
    tokenKey,
    userKey: "medicare.user",
    query(params) {
      const query = new URLSearchParams();
      Object.entries(params).forEach(([key, value]) => {
        if (value !== null && value !== undefined && value !== "") query.set(key, value);
      });
      return query.toString();
    }
  };
})();
