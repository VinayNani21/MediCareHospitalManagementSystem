(() => {
  const api = "/api/auth";
  const form = document.querySelector("#login-form") || document.querySelector("#register-form");
  if (!form) return;
  const error = document.querySelector("#form-error");
  form.addEventListener("submit", async event => {
    event.preventDefault();
    const button = form.querySelector("button[type=submit]");
    button.disabled = true;
    button.textContent = "Please wait…";
    error.textContent = "";
    const data = Object.fromEntries(new FormData(form));
    try {
      const endpoint = form.id === "login-form" ? "/login" : "/register";
      const response = await fetch(api + endpoint, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data)
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || "Unable to continue.");
      localStorage.setItem("medicare.jwt", result.token);
      localStorage.setItem("medicare.user", JSON.stringify(result.user));
      location.href = "/app.html";
    } catch (e) {
      error.textContent = e.message || "Unable to connect to Medicare.";
      button.disabled = false;
      button.textContent = form.id === "login-form" ? "Log in" : "Create patient account";
    }
  });
  if (new URLSearchParams(location.search).has("expired")) error.textContent = "Your session expired. Please log in again.";
})();
