package com.medicare.appointment;

import jakarta.validation.constraints.*;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;

public final class AppointmentDtos {
    private AppointmentDtos() {}
    public record Create(@NotNull @Positive Long doctorId, @NotNull LocalDate date, @NotNull LocalTime startTime,
                         @NotBlank @Size(max=500) String reason, @NotNull AppointmentType type) {}
    public record ReceptionCreate(@NotNull @Positive Long patientId, @NotNull @Positive Long doctorId, @NotNull LocalDate date,
                                  @NotNull LocalTime startTime, @NotBlank @Size(max=500) String reason, @NotNull AppointmentType type) {}
    public record Reschedule(@NotNull LocalDate date, @NotNull LocalTime startTime) {}
    public record View(Long id, Long patientId, String patientName, Long doctorId, String doctorName,
                       Long departmentId, String departmentName, LocalDate date, LocalTime startTime,
                       LocalTime endTime, String reason, AppointmentType type, AppointmentStatus status,
                       String notes, Instant createdAt, Instant updatedAt) {}
}
