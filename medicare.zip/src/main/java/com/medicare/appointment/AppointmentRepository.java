package com.medicare.appointment;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import jakarta.persistence.LockModeType;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select d from Doctor d where d.id = :id")
    Optional<com.medicare.doctor.Doctor> lockDoctor(@Param("id") Long id);

    @Query("""
        select a from Appointment a
        where (:doctorId is null or a.doctor.id = :doctorId)
          and (:patientId is null or a.patient.id = :patientId)
          and (:departmentId is null or a.department.id = :departmentId)
          and (:date is null or a.appointmentDate = :date)
          and (:status is null or a.status = :status)
        """)
    Page<Appointment> search(@Param("doctorId") Long doctorId, @Param("patientId") Long patientId,
             @Param("departmentId") Long departmentId, @Param("date") LocalDate date,
             @Param("status") AppointmentStatus status, Pageable pageable);

    @Query("""
        select count(a) > 0 from Appointment a where a.doctor.id = :doctorId
          and a.appointmentDate = :date and a.status not in :ignored
          and a.startTime < :end and a.endTime > :start
        """)
    boolean hasConflict(@Param("doctorId") Long doctorId, @Param("date") LocalDate date,
                        @Param("start") LocalTime start, @Param("end") LocalTime end,
                        @Param("ignored") List<AppointmentStatus> ignored);
    @Query("""
        select count(a) > 0 from Appointment a where a.patient.id = :patientId
          and a.appointmentDate = :date and a.status not in :ignored
          and a.startTime < :end and a.endTime > :start
        """)
    boolean patientHasConflict(@Param("patientId") Long patientId, @Param("date") LocalDate date,
                              @Param("start") LocalTime start, @Param("end") LocalTime end,
                              @Param("ignored") List<AppointmentStatus> ignored);
    boolean existsByDoctorIdAndPatientId(Long doctorId, Long patientId);
    List<Appointment> findByPatientIdAndAppointmentDateGreaterThanEqualOrderByAppointmentDateAscStartTimeAsc(Long id, LocalDate date);
    List<Appointment> findByDoctorIdAndAppointmentDateOrderByStartTimeAsc(Long id, LocalDate date);
    List<Appointment> findByDoctorIdAndAppointmentDateGreaterThanEqualOrderByAppointmentDateAscStartTimeAsc(Long id, LocalDate date);
    List<Appointment> findByAppointmentDate(LocalDate date);
    long countByAppointmentDate(LocalDate date);
    long countByStatus(AppointmentStatus status);
}
