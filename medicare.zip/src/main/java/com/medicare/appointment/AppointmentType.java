package com.medicare.appointment;

public enum AppointmentType { IN_PERSON, ONLINE }
