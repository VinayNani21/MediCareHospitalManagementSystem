package com.medicare.appointment;

import com.medicare.department.Department;
import com.medicare.doctor.Doctor;
import com.medicare.patient.Patient;
import jakarta.persistence.*;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "appointments", indexes = {
        @Index(name = "idx_appointment_doctor_date", columnList = "doctor_id,appointment_date"),
        @Index(name = "idx_appointment_patient_date", columnList = "patient_id,appointment_date")
})
public class Appointment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(optional = false) private Patient patient;
    @ManyToOne(optional = false) private Doctor doctor;
    @ManyToOne(optional = false) private Department department;
    @Column(name = "appointment_date", nullable = false) private LocalDate appointmentDate;
    @Column(nullable = false) private LocalTime startTime;
    @Column(nullable = false) private LocalTime endTime;
    @Column(nullable = false, length = 500) private String reason;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 20) private AppointmentType type;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 24) private AppointmentStatus status = AppointmentStatus.REQUESTED;
    @Column(length = 1000) private String notes;
    @Column(nullable = false, updatable = false) private Instant createdAt = Instant.now();
    @Column(nullable = false) private Instant updatedAt = Instant.now();
    protected Appointment() {}
    public Appointment(Patient patient, Doctor doctor, LocalDate date, LocalTime start, LocalTime end, String reason, AppointmentType type) {
        this.patient = patient; this.doctor = doctor; this.department = doctor.getDepartment();
        this.appointmentDate = date; this.startTime = start; this.endTime = end; this.reason = reason; this.type = type;
    }
    @PreUpdate void touch() { updatedAt = Instant.now(); }
    public Long getId() { return id; }
    public Patient getPatient() { return patient; }
    public Doctor getDoctor() { return doctor; }
    public Department getDepartment() { return department; }
    public LocalDate getAppointmentDate() { return appointmentDate; }
    public LocalTime getStartTime() { return startTime; }
    public LocalTime getEndTime() { return endTime; }
    public String getReason() { return reason; }
    public AppointmentType getType() { return type; }
    public AppointmentStatus getStatus() { return status; }
    public void setStatus(AppointmentStatus status) { this.status = status; }
    public void reschedule(LocalDate date, LocalTime start, LocalTime end) {
        this.appointmentDate = date; this.startTime = start; this.endTime = end;
        this.status = AppointmentStatus.RESCHEDULED;
    }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
}
