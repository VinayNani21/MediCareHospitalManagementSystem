package com.medicare.appointment;

public enum AppointmentStatus {
    REQUESTED, CONFIRMED, CANCELLED, RESCHEDULED, CHECKED_IN, IN_CONSULTATION, COMPLETED, NO_SHOW
}
