package com.medicare.appointment;

import com.medicare.common.CurrentUser;
import com.medicare.common.DomainException;
import com.medicare.patient.PatientRepository;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController {
    private final AppointmentService service;
    private final CurrentUser current;
    private final PatientRepository patients;
    private final AppointmentRepository appointments;
    public AppointmentController(AppointmentService service, CurrentUser current, PatientRepository patients, AppointmentRepository appointments) {
        this.service = service; this.current = current; this.patients = patients; this.appointments = appointments;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('PATIENT')")
    public AppointmentDtos.View book(Authentication authentication, @Valid @RequestBody AppointmentDtos.Create request) {
        var patient = patients.findByUserId(current.require(authentication).getId())
                .orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Patient profile not found."));
        return service.book(patient, request);
    }

    @PostMapping("/for-patient")
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAnyRole('RECEPTIONIST','ADMIN')")
    public AppointmentDtos.View createForPatient(Authentication authentication, @Valid @RequestBody AppointmentDtos.ReceptionCreate request) {
        return service.bookForPatient(request, current.require(authentication));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('PATIENT','DOCTOR','RECEPTIONIST','ADMIN')")
    public Page<AppointmentDtos.View> list(Authentication authentication, @RequestParam(required=false) Long doctorId,
            @RequestParam(required=false) Long patientId, @RequestParam(required=false) Long departmentId,
            @RequestParam(required=false) LocalDate date, @RequestParam(required=false) AppointmentStatus status,
            @RequestParam(defaultValue="0") int page, @RequestParam(defaultValue="20") int size) {
        return service.list(current.require(authentication), doctorId, patientId, departmentId, date, status, page, size);
    }

    @GetMapping("/{id}")
    public AppointmentDtos.View get(Authentication authentication, @PathVariable Long id) {
        var actor = current.require(authentication);
        Appointment a = appointments.findById(id).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Appointment not found."));
        boolean allowed = actor.getRole().name().equals("ADMIN") || actor.getRole().name().equals("RECEPTIONIST")
                || actor.getRole().name().equals("PATIENT") && a.getPatient().getUser().getId().equals(actor.getId())
                || actor.getRole().name().equals("DOCTOR") && a.getDoctor().getUser().getId().equals(actor.getId());
        if (!allowed) throw new DomainException(HttpStatus.FORBIDDEN, "You cannot view this appointment.");
        return new AppointmentDtos.View(a.getId(), a.getPatient().getId(), a.getPatient().getUser().getFullName(),
                a.getDoctor().getId(), a.getDoctor().getUser().getFullName(), a.getDepartment().getId(), a.getDepartment().getName(),
                a.getAppointmentDate(), a.getStartTime(), a.getEndTime(), a.getReason(), a.getType(), a.getStatus(),
                a.getNotes(), a.getCreatedAt(), a.getUpdatedAt());
    }

    @PostMapping("/{id}/cancel")
    public AppointmentDtos.View cancel(Authentication authentication, @PathVariable Long id) {
        return service.changeStatus(id, AppointmentStatus.CANCELLED, current.require(authentication));
    }
    @PostMapping("/{id}/confirm")
    @PreAuthorize("hasAnyRole('RECEPTIONIST','ADMIN')")
    public AppointmentDtos.View confirm(Authentication authentication, @PathVariable Long id) {
        return service.changeStatus(id, AppointmentStatus.CONFIRMED, current.require(authentication));
    }
    @PostMapping("/{id}/check-in")
    @PreAuthorize("hasAnyRole('RECEPTIONIST','ADMIN')")
    public AppointmentDtos.View checkIn(Authentication authentication, @PathVariable Long id) {
        return service.changeStatus(id, AppointmentStatus.CHECKED_IN, current.require(authentication));
    }
    @PostMapping("/{id}/start")
    @PreAuthorize("hasAnyRole('DOCTOR','ADMIN')")
    public AppointmentDtos.View start(Authentication authentication, @PathVariable Long id) {
        return service.changeStatus(id, AppointmentStatus.IN_CONSULTATION, current.require(authentication));
    }
    @PostMapping("/{id}/complete")
    @PreAuthorize("hasAnyRole('DOCTOR','ADMIN')")
    public AppointmentDtos.View complete(Authentication authentication, @PathVariable Long id) {
        return service.changeStatus(id, AppointmentStatus.COMPLETED, current.require(authentication));
    }
    @PostMapping("/{id}/no-show")
    @PreAuthorize("hasAnyRole('RECEPTIONIST','ADMIN')")
    public AppointmentDtos.View noShow(Authentication authentication, @PathVariable Long id) {
        return service.changeStatus(id, AppointmentStatus.NO_SHOW, current.require(authentication));
    }
    @PostMapping("/{id}/reschedule")
    @PreAuthorize("hasAnyRole('PATIENT','RECEPTIONIST','ADMIN')")
    public AppointmentDtos.View reschedule(Authentication authentication, @PathVariable Long id, @Valid @RequestBody AppointmentDtos.Reschedule request) {
        return service.reschedule(id, request, current.require(authentication));
    }
}
