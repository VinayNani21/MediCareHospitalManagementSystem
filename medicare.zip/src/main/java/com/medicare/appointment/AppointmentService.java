package com.medicare.appointment;

import com.medicare.availability.DoctorAvailability;
import com.medicare.availability.DoctorAvailabilityRepository;
import com.medicare.common.DomainException;
import com.medicare.common.AuditService;
import com.medicare.doctor.Doctor;
import com.medicare.doctor.DoctorRepository;
import com.medicare.notification.Notification;
import com.medicare.notification.NotificationRepository;
import com.medicare.patient.Patient;
import com.medicare.patient.PatientRepository;
import com.medicare.user.User;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.*;
import java.util.List;

@Service
public class AppointmentService {
    private static final List<AppointmentStatus> NON_BLOCKING = List.of(AppointmentStatus.CANCELLED);
    private final AppointmentRepository appointments;
    private final DoctorRepository doctors;
    private final PatientRepository patients;
    private final DoctorAvailabilityRepository availability;
    private final NotificationRepository notifications;
    private final AuditService audit;

    public AppointmentService(AppointmentRepository appointments, DoctorRepository doctors, PatientRepository patients,
            DoctorAvailabilityRepository availability, NotificationRepository notifications, AuditService audit) {
        this.appointments = appointments; this.doctors = doctors; this.patients = patients;
        this.availability = availability;                 this.notifications = notifications; this.audit = audit;
    }

    @Transactional
    public AppointmentDtos.View book(Patient patient, AppointmentDtos.Create request) {
        return view(create(patient, request.doctorId(), request.date(), request.startTime(), request.reason(), request.type(), patient.getUser()));
    }

    @Transactional
    public AppointmentDtos.View bookForPatient(AppointmentDtos.ReceptionCreate request, User actor) {
        Patient patient = patients.findById(request.patientId()).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Patient not found."));
        return view(create(patient, request.doctorId(), request.date(), request.startTime(), request.reason(), request.type(), actor));
    }

    @Transactional
    public AppointmentDtos.View changeStatus(Long id, AppointmentStatus target, User actor) {
        Appointment a = appointment(id);
        String role = actor.getRole().name();
        if (role.equals("PATIENT") && target != AppointmentStatus.CANCELLED
                || role.equals("DOCTOR") && target != AppointmentStatus.IN_CONSULTATION && target != AppointmentStatus.COMPLETED
                || role.equals("RECEPTIONIST") && target != AppointmentStatus.CONFIRMED && target != AppointmentStatus.CANCELLED
                    && target != AppointmentStatus.CHECKED_IN && target != AppointmentStatus.NO_SHOW)
            throw new DomainException(HttpStatus.FORBIDDEN, "Your role cannot perform this appointment action.");
        switch (target) {
            case CONFIRMED -> requireStatus(a, AppointmentStatus.REQUESTED, AppointmentStatus.RESCHEDULED);
            case CANCELLED -> {
                if (a.getStatus() == AppointmentStatus.COMPLETED || a.getStatus() == AppointmentStatus.CANCELLED)
                    throw new DomainException(HttpStatus.CONFLICT, "This appointment cannot be cancelled.");
                if (actor.getRole().name().equals("PATIENT") && !a.getPatient().getUser().getId().equals(actor.getId()))
                    throw new DomainException(HttpStatus.FORBIDDEN, "You can only cancel your own appointments.");
            }
            case CHECKED_IN -> requireStatus(a, AppointmentStatus.CONFIRMED);
            case IN_CONSULTATION -> requireStatus(a, AppointmentStatus.CHECKED_IN);
            case COMPLETED -> requireStatus(a, AppointmentStatus.IN_CONSULTATION);
            case NO_SHOW -> requireStatus(a, AppointmentStatus.CONFIRMED);
            default -> throw new DomainException(HttpStatus.BAD_REQUEST, "Unsupported appointment status transition.");
        }
        if (actor.getRole().name().equals("DOCTOR") && !a.getDoctor().getUser().getId().equals(actor.getId()))
            throw new DomainException(HttpStatus.FORBIDDEN, "Appointment is not assigned to you.");
        a.setStatus(target);
        audit.record(actor.getEmail(), "APPOINTMENT_" + target.name(), "appointmentId=" + a.getId());
        notify(a.getPatient().getUser(), "Appointment " + target.name().toLowerCase().replace('_',' '),
                "Your appointment with Dr. " + a.getDoctor().getUser().getFullName() + " is " + target.name().toLowerCase().replace('_',' ') + ".");
        if (target == AppointmentStatus.RESCHEDULED || target == AppointmentStatus.CONFIRMED || target == AppointmentStatus.CANCELLED)
            notify(a.getDoctor().getUser(), "Appointment updated", "An appointment was " + target.name().toLowerCase() + ".");
        return view(appointments.save(a));
    }

    @Transactional
    public AppointmentDtos.View reschedule(Long id, AppointmentDtos.Reschedule request, User actor) {
        Appointment a = appointment(id);
        if (!actor.getRole().name().equals("ADMIN") && !actor.getRole().name().equals("RECEPTIONIST")
                && !actor.getRole().name().equals("PATIENT"))
            throw new DomainException(HttpStatus.FORBIDDEN, "Your role cannot reschedule appointments.");
        if (actor.getRole().name().equals("PATIENT") && !a.getPatient().getUser().getId().equals(actor.getId()))
            throw new DomainException(HttpStatus.FORBIDDEN, "You can only reschedule your own appointments.");
        if (a.getStatus() == AppointmentStatus.CANCELLED || a.getStatus() == AppointmentStatus.COMPLETED)
            throw new DomainException(HttpStatus.CONFLICT, "This appointment cannot be rescheduled.");
        a.setStatus(AppointmentStatus.CANCELLED);
        patients.lockPatient(a.getPatient().getId()).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Patient not found."));
        appointments.lockDoctor(a.getDoctor().getId()).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Doctor not found."));
        LocalTime end = validateSlot(a.getDoctor(), request.date(), request.startTime());
        if (appointments.patientHasConflict(a.getPatient().getId(), request.date(), request.startTime(), end, NON_BLOCKING))
            throw new DomainException(HttpStatus.CONFLICT, "The patient already has an appointment during this time.");
        a.reschedule(request.date(), request.startTime(), end);
        audit.record(actor.getEmail(), "APPOINTMENT_RESCHEDULED", "appointmentId=" + a.getId());
        notify(a.getPatient().getUser(), "Appointment rescheduled", "Your appointment has been rescheduled.");
        notify(a.getDoctor().getUser(), "Appointment rescheduled", "An appointment has been rescheduled.");
        return view(appointments.save(a));
    }

    @Transactional(readOnly = true)
    public Page<AppointmentDtos.View> list(User actor, Long doctorId, Long patientId, Long departmentId,
                                            LocalDate date, AppointmentStatus status, int page, int size) {
        if (page < 0 || size < 1 || size > 100) throw new DomainException(HttpStatus.BAD_REQUEST, "Invalid pagination parameters.");
        if (actor.getRole().name().equals("PATIENT")) {
            Patient patient = patients.findByUserId(actor.getId()).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Patient profile not found."));
            patientId = patient.getId(); doctorId = null;
        } else if (actor.getRole().name().equals("DOCTOR")) {
            Doctor doctor = doctors.findByUserId(actor.getId()).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Doctor profile not found."));
            doctorId = doctor.getId(); patientId = null;
        }
        return appointments.search(doctorId, patientId, departmentId, date, status,
                PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "appointmentDate").and(Sort.by("startTime")))).map(this::view);
    }

    public List<AppointmentDtos.View> ownSchedule(User actor, LocalDate date) {
        List<Appointment> items;
        if (actor.getRole().name().equals("DOCTOR")) {
            Doctor doctor = doctors.findByUserId(actor.getId()).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Doctor profile not found."));
            items = date == null
                    ? appointments.findByDoctorIdAndAppointmentDateGreaterThanEqualOrderByAppointmentDateAscStartTimeAsc(doctor.getId(), LocalDate.now())
                    : appointments.findByDoctorIdAndAppointmentDateOrderByStartTimeAsc(doctor.getId(), date);
            if (date == null) items = items.stream().filter(a -> List.of(AppointmentStatus.REQUESTED,
                    AppointmentStatus.CONFIRMED, AppointmentStatus.RESCHEDULED, AppointmentStatus.CHECKED_IN,
                    AppointmentStatus.IN_CONSULTATION).contains(a.getStatus())).toList();
        } else if (actor.getRole().name().equals("PATIENT")) {
            Patient patient = patients.findByUserId(actor.getId()).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Patient profile not found."));
            items = appointments.findByPatientIdAndAppointmentDateGreaterThanEqualOrderByAppointmentDateAscStartTimeAsc(patient.getId(), LocalDate.now())
                    .stream().filter(a -> List.of(AppointmentStatus.REQUESTED, AppointmentStatus.CONFIRMED,
                            AppointmentStatus.RESCHEDULED, AppointmentStatus.CHECKED_IN, AppointmentStatus.IN_CONSULTATION)
                            .contains(a.getStatus())).toList();
        } else {
            items = appointments.findByAppointmentDate(date == null ? LocalDate.now() : date);
        }

        return items.stream().map(this::view).toList();
    }

    public List<AppointmentDtos.View> upcomingPatient(User actor) {
        if (!actor.getRole().name().equals("PATIENT"))
            throw new DomainException(HttpStatus.FORBIDDEN, "Patient dashboard data is not available to this account.");
        return ownSchedule(actor, null);
    }

    private Appointment create(Patient patient, Long doctorId, LocalDate date, LocalTime start, String reason, AppointmentType type, User actor) {
        Doctor doctor = appointments.lockDoctor(doctorId).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Doctor not found."));
        Patient lockedPatient = patients.lockPatient(patient.getId()).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Patient not found."));
        LocalTime end = validateSlot(doctor, date, start);
        if (appointments.patientHasConflict(lockedPatient.getId(), date, start, end, NON_BLOCKING))
            throw new DomainException(HttpStatus.CONFLICT, "The patient already has an appointment during this time.");
        Appointment a = appointments.save(new Appointment(lockedPatient, doctor, date, start, end, reason, type));
        audit.record(actor.getEmail(), "APPOINTMENT_CREATED", "appointmentId=" + a.getId());
        notify(lockedPatient.getUser(), "Appointment requested", "Your appointment request has been submitted.");
        notify(doctor.getUser(), "New appointment request", "A new appointment request is waiting for confirmation.");
        return a;
    }

    private LocalTime validateSlot(Doctor doctor, LocalDate date, LocalTime start) {
        if (!doctor.isAvailable()) throw new DomainException(HttpStatus.CONFLICT, "Doctor is not accepting appointments.");
        if (date == null || date.isBefore(LocalDate.now()) || date.equals(LocalDate.now()) && !start.isAfter(LocalTime.now()))
            throw new DomainException(HttpStatus.BAD_REQUEST, "Appointments cannot be booked in the past.");
        for (DoctorAvailability rule : availability.findByDoctorIdAndWorkingDayAndActiveTrue(doctor.getId(), date.getDayOfWeek())) {
            if (start.isBefore(rule.getStartTime())) continue;
            LocalTime end = start.plusMinutes(rule.getAppointmentDurationMinutes());
            if (end.isAfter(rule.getEndTime())) continue;
            if (rule.getBreakStart() != null && start.isBefore(rule.getBreakEnd()) && end.isAfter(rule.getBreakStart())) continue;
            if ((start.toSecondOfDay() - rule.getStartTime().toSecondOfDay()) % (rule.getAppointmentDurationMinutes() * 60) != 0) continue;
            if (appointments.hasConflict(doctor.getId(), date, start, end, NON_BLOCKING))
                throw new DomainException(HttpStatus.CONFLICT, "This time slot has already been booked.");
            return end;
        }
        throw new DomainException(HttpStatus.BAD_REQUEST, "Selected time is outside the doctor's available appointment slots.");
    }

    private Appointment appointment(Long id) {
        return appointments.findById(id).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Appointment not found."));
    }
    private void requireStatus(Appointment a, AppointmentStatus... permitted) {
        for (AppointmentStatus status : permitted) if (a.getStatus() == status) return;
        throw new DomainException(HttpStatus.CONFLICT, "Invalid appointment status transition from " + a.getStatus() + ".");
    }
    private void notify(User user, String title, String message) { notifications.save(new Notification(user, title, message)); }
    private AppointmentDtos.View view(Appointment a) {
        return new AppointmentDtos.View(a.getId(), a.getPatient().getId(), a.getPatient().getUser().getFullName(),
                a.getDoctor().getId(), a.getDoctor().getUser().getFullName(), a.getDepartment().getId(), a.getDepartment().getName(),
                a.getAppointmentDate(), a.getStartTime(), a.getEndTime(), a.getReason(), a.getType(), a.getStatus(),
                a.getNotes(), a.getCreatedAt(), a.getUpdatedAt());
    }
}
