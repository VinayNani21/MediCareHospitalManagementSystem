package com.medicare.dashboard;

import com.medicare.appointment.*;
import com.medicare.common.CurrentUser;
import com.medicare.common.DomainException;
import com.medicare.consultation.*;
import com.medicare.department.DepartmentRepository;
import com.medicare.doctor.DoctorRepository;
import com.medicare.notification.NotificationController;
import com.medicare.notification.NotificationRepository;
import com.medicare.patient.PatientRepository;
import com.medicare.user.Role;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.*;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {
    private final CurrentUser current;
    private final AppointmentService appointmentService;
    private final AppointmentRepository appointments;
    private final PatientRepository patients;
    private final DoctorRepository doctors;
    private final DepartmentRepository departments;
    private final ConsultationRepository consultations;
    private final ConsultationService consultationService;
    private final PrescriptionService prescriptionService;
    private final PrescriptionRepository prescriptions;
    private final NotificationRepository notifications;
    public DashboardController(CurrentUser current, AppointmentService appointmentService, AppointmentRepository appointments,
            PatientRepository patients, DoctorRepository doctors, DepartmentRepository departments,
            ConsultationRepository consultations, ConsultationService consultationService, PrescriptionService prescriptionService,
            PrescriptionRepository prescriptions, NotificationRepository notifications) {
        this.current = current; this.appointmentService = appointmentService; this.appointments = appointments;
        this.patients = patients; this.doctors = doctors; this.departments = departments; this.consultations = consultations;
        this.consultationService = consultationService; this.prescriptionService = prescriptionService;
        this.prescriptions = prescriptions; this.notifications = notifications;
    }

    @GetMapping("/patient")
    @PreAuthorize("hasRole('PATIENT')")
    public Map<String, Object> patient(Authentication auth) {
        var user = current.require(auth);
        var patient = patients.findByUserId(user.getId()).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Patient profile not found."));
        var all = appointmentService.upcomingPatient(user);
        return Map.of("welcome", user.getFullName(), "upcomingAppointments", all, "consultationHistory",
                consultationService.patientHistory(patient.getId()), "prescriptions", prescriptionService.mine(user), "unreadNotifications",
                notifications.countByUserIdAndReadFalse(user.getId()));
    }

    @GetMapping("/doctor")
    @PreAuthorize("hasRole('DOCTOR')")
    public Map<String, Object> doctor(Authentication auth) {
        var user = current.require(auth);
        var todays = appointmentService.ownSchedule(user, LocalDate.now());
        var upcoming = appointmentService.ownSchedule(user, null);
        return Map.of("welcome", user.getFullName(), "today", todays, "upcoming", upcoming,
                "checkedIn", todays.stream().filter(a -> a.status() == AppointmentStatus.CHECKED_IN).toList(),
                "pendingConsultations", todays.stream().filter(a -> a.status() == AppointmentStatus.CHECKED_IN
                        || a.status() == AppointmentStatus.IN_CONSULTATION).toList(),
                "completedToday", todays.stream().filter(a -> a.status() == AppointmentStatus.COMPLETED).toList());
    }

    @GetMapping("/receptionist")
    @PreAuthorize("hasAnyRole('RECEPTIONIST','ADMIN')")
    public Map<String, Object> receptionist(Authentication auth) {
        var today = appointmentService.list(current.require(auth), null, null, null, LocalDate.now(), null, 0, 100).getContent();
        return Map.of("today", today, "waiting", today.stream().filter(a -> a.status() == AppointmentStatus.CHECKED_IN).toList(),
                "cancelled", today.stream().filter(a -> a.status() == AppointmentStatus.CANCELLED).toList(),
                "noShows", today.stream().filter(a -> a.status() == AppointmentStatus.NO_SHOW).toList());
    }

    @GetMapping("/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public Map<String, Object> admin() {
        Map<String, Long> byStatus = new LinkedHashMap<>();
        for (AppointmentStatus status : AppointmentStatus.values()) byStatus.put(status.name(), appointments.countByStatus(status));
        Map<String, Long> byDepartment = new LinkedHashMap<>();
        departments.findAll().forEach(d -> byDepartment.put(d.getName(), doctors.countByDepartmentId(d.getId())));
        return Map.of("totalPatients", patients.count(), "totalDoctors", doctors.count(), "totalAppointments", appointments.count(),
                "todayAppointments", appointments.countByAppointmentDate(LocalDate.now()), "statusSummary", byStatus,
                "departmentSummary", byDepartment);
    }
}
