package com.medicare.config;

import com.medicare.appointment.*;
import com.medicare.availability.*;
import com.medicare.consultation.*;
import com.medicare.department.*;
import com.medicare.doctor.*;
import com.medicare.notification.*;
import com.medicare.patient.*;
import com.medicare.user.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.*;
import java.util.List;

@Configuration
public class SeedDataConfig {
    @Bean
    CommandLineRunner seedData(SeedRunner runner, @Value("${app.seed.enabled:true}") boolean enabled) {
        return args -> { if (enabled) runner.seed(); };
    }

    @org.springframework.stereotype.Component
    static class SeedRunner {
        private static final String PASSWORD = "DemoPass123!";
        private final UserRepository users;
        private final PatientRepository patients;
        private final DepartmentRepository departments;
        private final DoctorRepository doctors;
        private final DoctorAvailabilityRepository availability;
        private final AppointmentRepository appointments;
        private final ConsultationRepository consultations;
        private final PrescriptionRepository prescriptions;
        private final PrescriptionItemRepository items;
        private final NotificationRepository notifications;
        private final PasswordEncoder encoder;

        SeedRunner(UserRepository users, PatientRepository patients, DepartmentRepository departments, DoctorRepository doctors,
                   DoctorAvailabilityRepository availability, AppointmentRepository appointments, ConsultationRepository consultations,
                   PrescriptionRepository prescriptions, PrescriptionItemRepository items, NotificationRepository notifications,
                   PasswordEncoder encoder) {
            this.users = users; this.patients = patients; this.departments = departments; this.doctors = doctors;
            this.availability = availability; this.appointments = appointments; this.consultations = consultations;
            this.prescriptions = prescriptions; this.items = items; this.notifications = notifications; this.encoder = encoder;
        }

        @Transactional
        public void seed() {
            User admin = user("admin@medicare.test", "Medicare Admin", Role.ADMIN, "9000000001");
            User receptionist = user("reception@medicare.test", "Medicare Reception", Role.RECEPTIONIST, "9000000002");
            Department cardiology = departments.findAll().stream().filter(d -> d.getName().equals("Cardiology")).findFirst()
                    .orElseGet(() -> departments.save(new Department("Cardiology", "Heart and cardiovascular care.")));
            Department family = departments.findAll().stream().filter(d -> d.getName().equals("Family Medicine")).findFirst()
                    .orElseGet(() -> departments.save(new Department("Family Medicine", "Primary and preventive care.")));
            Department pediatrics = departments.findAll().stream().filter(d -> d.getName().equals("Pediatrics")).findFirst()
                    .orElseGet(() -> departments.save(new Department("Pediatrics", "Healthcare for infants, children and adolescents.")));
            Doctor d1 = doctor("doctor.lee@medicare.test", "Dr. Avery Lee", "9000000011", cardiology, "Cardiology", "MD, FACC", "120.00", 12);
            Doctor d2 = doctor("doctor.patel@medicare.test", "Dr. Sam Patel", "9000000012", family, "Family Medicine", "MD", "85.00", 8);
            Doctor d3 = doctor("doctor.rao@medicare.test", "Dr. Maya Rao", "9000000013", cardiology, "Interventional Cardiology", "MD, DM (Cardiology)", "150.00", 10);
            Doctor d4 = doctor("doctor.williams@medicare.test", "Dr. Olivia Williams", "9000000014", pediatrics, "Pediatrics", "MD, FAAP", "95.00", 11);
            Doctor d5 = doctor("doctor.khan@medicare.test", "Dr. Noor Khan", "9000000015", family, "Family Medicine", "MD", "75.00", 6);
            Doctor d6 = doctor("doctor.shah@medicare.test", "Dr. Arjun Shah", "9000000016", pediatrics, "Pediatrics", "MD", "90.00", 7);
            user("patient.jordan@medicare.test", "Jordan Morgan", Role.PATIENT, "9000000021");
            user("patient.taylor@medicare.test", "Taylor Quinn", Role.PATIENT, "9000000022");
            user("patient.casey@medicare.test", "Casey Rivera", Role.PATIENT, "9000000023");
            makePatient("patient.jordan@medicare.test");
            makePatient("patient.taylor@medicare.test");
            makePatient("patient.casey@medicare.test");
            seedAvailability(d1); seedAvailability(d2); seedAvailability(d3);
            seedAvailability(d4); seedAvailability(d5); seedAvailability(d6);
            if (appointments.count() == 0) {
                Patient jordan = patients.findByUserId(users.findByEmailIgnoreCase("patient.jordan@medicare.test").orElseThrow().getId()).orElseThrow();
                LocalDate nextWorkDay = LocalDate.now().plusDays(1);
                while (nextWorkDay.getDayOfWeek() == DayOfWeek.SATURDAY || nextWorkDay.getDayOfWeek() == DayOfWeek.SUNDAY)
                    nextWorkDay = nextWorkDay.plusDays(1);
                Appointment next = new Appointment(jordan, d1, nextWorkDay, LocalTime.of(10, 0), LocalTime.of(10, 30),
                        "Routine heart health follow-up", AppointmentType.IN_PERSON);
                next.setStatus(AppointmentStatus.CONFIRMED);
                appointments.save(next);
                Appointment past = new Appointment(jordan, d1, LocalDate.now().minusDays(1), LocalTime.of(10, 0),
                        LocalTime.of(10, 30), "Annual wellness check", AppointmentType.IN_PERSON);
                past.setStatus(AppointmentStatus.COMPLETED);
                past = appointments.save(past);
                Consultation consultation = new Consultation(past);
                consultation.setSymptoms("No acute symptoms.");
                consultation.setVitalSigns("BP 118/76; pulse 72");
                consultation.setDiagnosis("Routine examination; stable.");
                consultation.setClinicalNotes("Continue routine preventive care.");
                consultation.setTreatmentInstructions("Maintain current activity and return for annual review.");
                consultation.setFinalized(true);
                consultation = consultations.save(consultation);
                Prescription prescription = prescriptions.save(new Prescription(consultation, "Take with food."));
                items.save(new PrescriptionItem(prescription, "Vitamin D3", "1000 IU", "Once daily", "30 days", "Take with breakfast."));
            }
            if (notifications.count() == 0) {
                notifications.save(new Notification(users.findByEmailIgnoreCase("patient.jordan@medicare.test").orElseThrow(),
                        "Welcome to Medicare", "Your patient account is ready."));
                notifications.save(new Notification(admin, "System ready", "Development seed data is available."));
                notifications.save(new Notification(receptionist, "Check-in desk", "Today's appointment list is ready."));
            }
        }

        private User user(String email, String name, Role role, String phone) {
            return users.findByEmailIgnoreCase(email).orElseGet(() -> users.save(new User(name, email, encoder.encode(PASSWORD), phone, role)));
        }
        private void makePatient(String email) {
            User u = users.findByEmailIgnoreCase(email).orElseThrow();
            if (patients.findByUserId(u.getId()).isEmpty())
                patients.save(new Patient(u, "MRN-" + String.format("%06d", u.getId())));
        }
        private Doctor doctor(String email, String name, String phone, Department department, String specialty,
                              String qualification, String fee, int experience) {
            User u = user(email, name, Role.DOCTOR, phone);
            return doctors.findByUserId(u.getId()).orElseGet(() -> doctors.save(new Doctor(u, department, specialty,
                    qualification, new BigDecimal(fee), experience)));
        }
        private void seedAvailability(Doctor doctor) {
            List<DoctorAvailability> existing = availability.findByDoctorId(doctor.getId());
            for (DayOfWeek day : List.of(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY,
                    DayOfWeek.THURSDAY, DayOfWeek.FRIDAY)) {
                if (existing.stream().noneMatch(a -> a.getWorkingDay() == day)) {
                    DoctorAvailability a = new DoctorAvailability(doctor, day, LocalTime.of(9, 0), LocalTime.of(17, 0), 30);
                    a.setBreakStart(LocalTime.of(12, 0)); a.setBreakEnd(LocalTime.of(13, 0));
                    availability.save(a);
                }
            }
        }
    }
}
