package com.medicare.availability;

import com.medicare.appointment.AppointmentRepository;
import com.medicare.appointment.AppointmentStatus;
import com.medicare.common.DomainException;
import com.medicare.doctor.Doctor;
import com.medicare.doctor.DoctorRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.time.*;
import java.util.ArrayList;
import java.util.List;

@RestController
public class AvailabilityController {
    private final DoctorAvailabilityRepository availability;
    private final DoctorRepository doctors;
    private final AppointmentRepository appointments;
    public AvailabilityController(DoctorAvailabilityRepository availability, DoctorRepository doctors, AppointmentRepository appointments) {
        this.availability = availability; this.doctors = doctors; this.appointments = appointments;
    }

    @GetMapping("/api/doctors/{doctorId}/availability")
    public List<AvailabilityDtos.View> list(@PathVariable Long doctorId) {
        requireDoctor(doctorId);
        return availability.findByDoctorId(doctorId).stream().map(this::view).toList();
    }

    @GetMapping("/api/doctors/{doctorId}/availability/slots")
    public List<AvailabilityDtos.Slot> slots(@PathVariable Long doctorId, @RequestParam LocalDate date) {
        Doctor doctor = requireDoctor(doctorId);
        if (!doctor.isAvailable()) throw new DomainException(HttpStatus.CONFLICT, "Doctor is not accepting appointments.");
        if (date.isBefore(LocalDate.now())) throw new DomainException(HttpStatus.BAD_REQUEST, "Date cannot be in the past.");
        List<AvailabilityDtos.Slot> slots = new ArrayList<>();
        for (DoctorAvailability rule : availability.findByDoctorIdAndWorkingDayAndActiveTrue(doctorId, date.getDayOfWeek())) {
            for (LocalTime start = rule.getStartTime(); !start.plusMinutes(rule.getAppointmentDurationMinutes()).isAfter(rule.getEndTime());
                 start = start.plusMinutes(rule.getAppointmentDurationMinutes())) {
                LocalTime end = start.plusMinutes(rule.getAppointmentDurationMinutes());
                if (rule.getBreakStart() != null && start.isBefore(rule.getBreakEnd()) && end.isAfter(rule.getBreakStart())) continue;
                if (date.equals(LocalDate.now()) && !start.isAfter(LocalTime.now())) continue;
                if (!appointments.hasConflict(doctorId, date, start, end, List.of(AppointmentStatus.CANCELLED)))
                    slots.add(new AvailabilityDtos.Slot(start, end));
            }
        }
        return slots;
    }

    @PostMapping("/api/doctors/{doctorId}/availability")
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('ADMIN')")
    public AvailabilityDtos.View create(@PathVariable Long doctorId, @Valid @RequestBody AvailabilityDtos.Request request) {
        Doctor doctor = requireDoctor(doctorId);
        validate(request);
        DoctorAvailability a = new DoctorAvailability(doctor, request.workingDay(), request.startTime(), request.endTime(), request.appointmentDurationMinutes());
        a.setBreakStart(request.breakStart()); a.setBreakEnd(request.breakEnd()); a.setActive(request.active());
        return view(availability.save(a));
    }

    @PutMapping("/api/doctors/{doctorId}/availability/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public AvailabilityDtos.View update(@PathVariable Long doctorId, @PathVariable Long id, @Valid @RequestBody AvailabilityDtos.Request request) {
        DoctorAvailability a = availability.findById(id).filter(x -> x.getDoctor().getId().equals(doctorId))
                .orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Availability record not found."));
        validate(request);
        a.setActive(request.active()); a.setBreakStart(request.breakStart()); a.setBreakEnd(request.breakEnd());
        // Scheduling rules are immutable after creation to avoid silently invalidating existing bookings.
        if (!a.getWorkingDay().equals(request.workingDay()) || !a.getStartTime().equals(request.startTime())
                || !a.getEndTime().equals(request.endTime()) || a.getAppointmentDurationMinutes() != request.appointmentDurationMinutes())
            throw new DomainException(HttpStatus.CONFLICT, "Delete and recreate an availability rule to change its time window.");
        return view(availability.save(a));
    }

    @DeleteMapping("/api/doctors/{doctorId}/availability/{id}")
    @org.springframework.security.access.prepost.PreAuthorize("hasRole('ADMIN')")
    @org.springframework.web.bind.annotation.ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long doctorId, @PathVariable Long id) {
        DoctorAvailability a = availability.findById(id).filter(x -> x.getDoctor().getId().equals(doctorId))
                .orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Availability record not found."));
        availability.delete(a);
    }

    private void validate(AvailabilityDtos.Request r) {
        if (!r.endTime().isAfter(r.startTime())) throw new DomainException(HttpStatus.BAD_REQUEST, "End time must be after start time.");
        if ((r.breakStart() == null) != (r.breakEnd() == null)
                || r.breakStart() != null && (!r.breakEnd().isAfter(r.breakStart())
                || r.breakStart().isBefore(r.startTime()) || r.breakEnd().isAfter(r.endTime())))
            throw new DomainException(HttpStatus.BAD_REQUEST, "Break must be within working hours and have a valid duration.");
    }
    private Doctor requireDoctor(Long id) {
        return doctors.findById(id).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Doctor not found."));
    }
    private AvailabilityDtos.View view(DoctorAvailability a) {
        return new AvailabilityDtos.View(a.getId(), a.getDoctor().getId(), a.getWorkingDay(), a.getStartTime(), a.getEndTime(),
                a.getAppointmentDurationMinutes(), a.getBreakStart(), a.getBreakEnd(), a.isActive());
    }
}
