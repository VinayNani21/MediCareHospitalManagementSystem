package com.medicare.availability;

import com.medicare.doctor.Doctor;
import jakarta.persistence.*;
import java.time.DayOfWeek;
import java.time.LocalTime;

@Entity
@Table(name = "doctor_availability", indexes = @Index(name = "idx_availability_doctor_day", columnList = "doctor_id,working_day"))
public class DoctorAvailability {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(optional = false) private Doctor doctor;
    @Enumerated(EnumType.STRING) @Column(name = "working_day", nullable = false) private DayOfWeek workingDay;
    @Column(nullable = false) private LocalTime startTime;
    @Column(nullable = false) private LocalTime endTime;
    @Column(nullable = false) private int appointmentDurationMinutes;
    private LocalTime breakStart;
    private LocalTime breakEnd;
    @Column(nullable = false) private boolean active = true;
    protected DoctorAvailability() {}
    public DoctorAvailability(Doctor doctor, DayOfWeek day, LocalTime start, LocalTime end, int duration) {
        this.doctor = doctor; this.workingDay = day; this.startTime = start; this.endTime = end; this.appointmentDurationMinutes = duration;
    }
    public Long getId() { return id; }
    public Doctor getDoctor() { return doctor; }
    public DayOfWeek getWorkingDay() { return workingDay; }
    public LocalTime getStartTime() { return startTime; }
    public LocalTime getEndTime() { return endTime; }
    public int getAppointmentDurationMinutes() { return appointmentDurationMinutes; }
    public LocalTime getBreakStart() { return breakStart; }
    public void setBreakStart(LocalTime breakStart) { this.breakStart = breakStart; }
    public LocalTime getBreakEnd() { return breakEnd; }
    public void setBreakEnd(LocalTime breakEnd) { this.breakEnd = breakEnd; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}
