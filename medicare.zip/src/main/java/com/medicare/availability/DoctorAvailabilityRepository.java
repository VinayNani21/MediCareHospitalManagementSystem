package com.medicare.availability;

import org.springframework.data.jpa.repository.JpaRepository;
import java.time.DayOfWeek;
import java.util.List;

public interface DoctorAvailabilityRepository extends JpaRepository<DoctorAvailability, Long> {
    List<DoctorAvailability> findByDoctorIdAndWorkingDayAndActiveTrue(Long doctorId, DayOfWeek day);
    List<DoctorAvailability> findByDoctorId(Long doctorId);
}
