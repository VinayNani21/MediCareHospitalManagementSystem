package com.medicare.availability;

import jakarta.validation.constraints.*;
import java.time.DayOfWeek;
import java.time.LocalTime;

public final class AvailabilityDtos {
    private AvailabilityDtos() {}
    public record Request(@NotNull DayOfWeek workingDay, @NotNull LocalTime startTime, @NotNull LocalTime endTime,
                          @Min(5) @Max(240) int appointmentDurationMinutes, LocalTime breakStart,
                          LocalTime breakEnd, boolean active) {}
    public record View(Long id, Long doctorId, DayOfWeek workingDay, LocalTime startTime, LocalTime endTime,
                       int appointmentDurationMinutes, LocalTime breakStart, LocalTime breakEnd, boolean active) {}
    public record Slot(LocalTime startTime, LocalTime endTime) {}
}
