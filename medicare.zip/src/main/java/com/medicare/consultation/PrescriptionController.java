package com.medicare.consultation;

import com.medicare.common.CurrentUser;
import com.medicare.common.DomainException;
import com.medicare.patient.PatientRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/prescriptions")
public class PrescriptionController {
    private final PrescriptionService prescriptionService;
    private final CurrentUser current;
    public PrescriptionController(PrescriptionService prescriptionService, CurrentUser current) {
        this.prescriptionService = prescriptionService; this.current = current;
    }
    @GetMapping("/mine")
    @PreAuthorize("hasRole('PATIENT')")
    public List<ConsultationDtos.PrescriptionView> mine(Authentication auth) {
        return prescriptionService.mine(current.require(auth));
    }
}
