package com.medicare.consultation;

import com.medicare.doctor.Doctor;
import com.medicare.patient.Patient;
import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "prescriptions")
public class Prescription {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @OneToOne(optional = false) @JoinColumn(nullable = false, unique = true) private Consultation consultation;
    @ManyToOne(optional = false) private Patient patient;
    @ManyToOne(optional = false) private Doctor doctor;
    @Column(nullable = false) private Instant prescriptionDate = Instant.now();
    @Column(length = 2000) private String generalInstructions;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private PrescriptionStatus status = PrescriptionStatus.ACTIVE;
    protected Prescription() {}
    public Prescription(Consultation consultation, String instructions) {
        this.consultation = consultation; this.patient = consultation.getPatient(); this.doctor = consultation.getDoctor(); this.generalInstructions = instructions;
    }
    public Long getId() { return id; }
    public Consultation getConsultation() { return consultation; }
    public Patient getPatient() { return patient; }
    public Doctor getDoctor() { return doctor; }
    public Instant getPrescriptionDate() { return prescriptionDate; }
    public String getGeneralInstructions() { return generalInstructions; }
    public void setGeneralInstructions(String value) { generalInstructions = value; }
    public PrescriptionStatus getStatus() { return status; }
    public void setStatus(PrescriptionStatus status) { this.status = status; }
}
