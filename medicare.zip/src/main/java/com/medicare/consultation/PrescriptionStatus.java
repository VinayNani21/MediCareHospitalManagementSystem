package com.medicare.consultation;

public enum PrescriptionStatus { ACTIVE, COMPLETED, CANCELLED }
