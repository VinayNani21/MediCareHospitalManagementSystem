package com.medicare.consultation;

import com.medicare.common.CurrentUser;
import com.medicare.common.DomainException;
import com.medicare.patient.PatientRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/consultations")
public class ConsultationController {
    private final ConsultationService consultations;
    private final CurrentUser current;
    private final PatientRepository patients;
    public ConsultationController(ConsultationService consultations, CurrentUser current, PatientRepository patients) {
        this.consultations = consultations; this.current = current; this.patients = patients;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('DOCTOR')")
    public ConsultationDtos.View create(Authentication auth, @Valid @RequestBody ConsultationDtos.Request request) {
        return consultations.save(current.require(auth), null, request);
    }
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('DOCTOR')")
    public ConsultationDtos.View update(Authentication auth, @PathVariable Long id, @Valid @RequestBody ConsultationDtos.Request request) {
        return consultations.save(current.require(auth), id, request);
    }
    @GetMapping("/{id}")
    public ConsultationDtos.View get(Authentication auth, @PathVariable Long id) {
        return consultations.get(current.require(auth), id);
    }
    @GetMapping("/by-appointment/{appointmentId}")
    public ConsultationDtos.View byAppointment(Authentication auth, @PathVariable Long appointmentId) {
        return consultations.getByAppointment(current.require(auth), appointmentId);
    }
    @GetMapping("/mine")
    @PreAuthorize("hasRole('PATIENT')")
    public List<ConsultationDtos.View> mine(Authentication auth) {
        var patient = patients.findByUserId(current.require(auth).getId())
                .orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Patient profile not found."));
        return consultations.patientHistory(patient.getId());
    }
}
