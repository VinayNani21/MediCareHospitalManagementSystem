package com.medicare.consultation;

import com.medicare.common.DomainException;
import com.medicare.patient.PatientRepository;
import com.medicare.user.User;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class PrescriptionService {
    private final PrescriptionRepository prescriptions;
    private final PrescriptionItemRepository items;
    private final PatientRepository patients;
    public PrescriptionService(PrescriptionRepository prescriptions, PrescriptionItemRepository items, PatientRepository patients) {
        this.prescriptions = prescriptions; this.items = items; this.patients = patients;
    }
    @Transactional(readOnly = true)
    public List<ConsultationDtos.PrescriptionView> mine(User user) {
        var patient = patients.findByUserId(user.getId())
                .orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Patient profile not found."));
        return prescriptions.findByPatientIdOrderByPrescriptionDateDesc(patient.getId()).stream().map(p ->
                new ConsultationDtos.PrescriptionView(p.getId(), p.getPrescriptionDate(), p.getGeneralInstructions(),
                        p.getStatus(), items.findByPrescriptionId(p.getId()).stream().map(i ->
                        new ConsultationDtos.MedicineView(i.getId(), i.getMedicineName(), i.getDosage(),
                                i.getFrequency(), i.getDuration(), i.getInstructions())).toList())).toList();
    }
}
