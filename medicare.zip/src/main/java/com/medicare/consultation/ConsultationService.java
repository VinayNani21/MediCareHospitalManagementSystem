package com.medicare.consultation;

import com.medicare.appointment.*;
import com.medicare.common.DomainException;
import com.medicare.common.AuditService;
import com.medicare.notification.Notification;
import com.medicare.notification.NotificationRepository;
import com.medicare.user.User;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class ConsultationService {
    private final ConsultationRepository consultations;
    private final AppointmentRepository appointments;
    private final PrescriptionRepository prescriptions;
    private final PrescriptionItemRepository items;
    private final NotificationRepository notifications;
    private final AuditService audit;
    public ConsultationService(ConsultationRepository consultations, AppointmentRepository appointments,
                               PrescriptionRepository prescriptions, PrescriptionItemRepository items,
                               NotificationRepository notifications, AuditService audit) {
        this.consultations = consultations; this.appointments = appointments; this.prescriptions = prescriptions;
        this.items = items; this.notifications = notifications; this.audit = audit;
    }

    @Transactional
    public ConsultationDtos.View save(User actor, Long id, ConsultationDtos.Request request) {
        Appointment appointment = appointments.findById(request.appointmentId())
                .orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Appointment not found."));
        if (!appointment.getDoctor().getUser().getId().equals(actor.getId()))
            throw new DomainException(HttpStatus.FORBIDDEN, "Only the assigned doctor can edit this consultation.");
        if (appointment.getStatus() != AppointmentStatus.CHECKED_IN
                && appointment.getStatus() != AppointmentStatus.IN_CONSULTATION
                && appointment.getStatus() != AppointmentStatus.COMPLETED)
            throw new DomainException(HttpStatus.CONFLICT, "Consultations require a checked-in or active appointment.");
        if (request.finalizeRecord() && appointment.getStatus() == AppointmentStatus.CHECKED_IN)
            throw new DomainException(HttpStatus.CONFLICT, "Start the consultation before finalizing it.");

        Consultation consultation;
        if (id == null) {
            if (consultations.findByAppointmentId(appointment.getId()).isPresent())
                throw new DomainException(HttpStatus.CONFLICT, "A consultation already exists for this appointment.");
            consultation = new Consultation(appointment);
        } else {
            consultation = consultations.findById(id).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Consultation not found."));
            if (!consultation.getAppointment().getId().equals(appointment.getId()))
                throw new DomainException(HttpStatus.BAD_REQUEST, "Consultation does not match the appointment.");
            if (consultation.isFinalized()) throw new DomainException(HttpStatus.CONFLICT, "Finalized consultations cannot be changed.");
        }
        consultation.setSymptoms(request.symptoms()); consultation.setVitalSigns(request.vitalSigns());
        consultation.setDiagnosis(request.diagnosis()); consultation.setClinicalNotes(request.clinicalNotes());
        consultation.setRecommendedTests(request.recommendedTests()); consultation.setTreatmentInstructions(request.treatmentInstructions());
        consultation.setFollowUpDate(request.followUpDate()); consultation.setFinalized(request.finalizeRecord());
        consultation = consultations.save(consultation);
        upsertPrescription(consultation, request);
        if (request.finalizeRecord() && appointment.getStatus() == AppointmentStatus.IN_CONSULTATION) {
            appointment.setStatus(AppointmentStatus.COMPLETED);
            appointments.save(appointment);
            notifications.save(new Notification(appointment.getPatient().getUser(), "Appointment completed",
                    "Your consultation with Dr. " + appointment.getDoctor().getUser().getFullName() + " is complete."));
            audit.record(actor.getEmail(), "CONSULTATION_FINALIZED", "consultationId=" + consultation.getId());
        }
        return view(consultation);
    }

    @Transactional(readOnly = true)
    public List<ConsultationDtos.View> patientHistory(Long patientId) {
        return consultations.findByPatientIdOrderByCreatedAtDesc(patientId).stream().map(this::view).toList();
    }

    @Transactional(readOnly = true)
    public ConsultationDtos.View get(User actor, Long id) {
        Consultation c = consultations.findById(id).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Consultation not found."));
        boolean permitted = actor.getRole().name().equals("ADMIN")
                || actor.getRole().name().equals("PATIENT") && c.getPatient().getUser().getId().equals(actor.getId())
                || actor.getRole().name().equals("DOCTOR") && c.getDoctor().getUser().getId().equals(actor.getId());
        if (!permitted) throw new DomainException(HttpStatus.FORBIDDEN, "You cannot view this consultation.");
        return view(c);
    }

    @Transactional(readOnly = true)
    public ConsultationDtos.View getByAppointment(User actor, Long appointmentId) {
        Consultation c = consultations.findByAppointmentId(appointmentId)
                .orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Consultation not found."));
        return get(actor, c.getId());
    }

    private void upsertPrescription(Consultation consultation, ConsultationDtos.Request request) {
        if (request.medicines() == null && request.prescriptionInstructions() == null) return;
        Prescription prescription = prescriptions.findByConsultationId(consultation.getId())
                .orElseGet(() -> prescriptions.save(new Prescription(consultation, request.prescriptionInstructions())));
        prescription.setGeneralInstructions(request.prescriptionInstructions());
        prescription = prescriptions.save(prescription);
        items.deleteByPrescriptionId(prescription.getId());
        if (request.medicines() != null)
            for (ConsultationDtos.Medicine medicine : request.medicines())
                items.save(new PrescriptionItem(prescription, medicine.medicineName(), medicine.dosage(),
                        medicine.frequency(), medicine.duration(), medicine.instructions()));
    }

    private ConsultationDtos.View view(Consultation c) {
        var p = prescriptions.findByConsultationId(c.getId()).orElse(null);
        ConsultationDtos.PrescriptionView prescription = p == null ? null : new ConsultationDtos.PrescriptionView(p.getId(),
                p.getPrescriptionDate(), p.getGeneralInstructions(), p.getStatus(), items.findByPrescriptionId(p.getId()).stream()
                .map(i -> new ConsultationDtos.MedicineView(i.getId(), i.getMedicineName(), i.getDosage(),
                        i.getFrequency(), i.getDuration(), i.getInstructions())).toList());
        return new ConsultationDtos.View(c.getId(), c.getAppointment().getId(), c.getPatient().getId(),
                c.getPatient().getUser().getFullName(), c.getDoctor().getId(), c.getDoctor().getUser().getFullName(),
                c.getSymptoms(), c.getVitalSigns(), c.getDiagnosis(), c.getClinicalNotes(), c.getRecommendedTests(),
                c.getTreatmentInstructions(), c.getFollowUpDate(), c.isFinalized(), c.getCreatedAt(), c.getUpdatedAt(), prescription);
    }
}
