package com.medicare.consultation;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

public final class ConsultationDtos {
    private ConsultationDtos() {}
    public record Medicine(@NotBlank @Size(max=150) String medicineName, @NotBlank @Size(max=100) String dosage,
                           @NotBlank @Size(max=100) String frequency, @NotBlank @Size(max=100) String duration,
                           @Size(max=500) String instructions) {}
    public record Request(@NotNull @Positive Long appointmentId, @Size(max=2000) String symptoms,
                          @Size(max=1000) String vitalSigns, @Size(max=2000) String diagnosis,
                          @Size(max=5000) String clinicalNotes, @Size(max=2000) String recommendedTests,
                          @Size(max=2000) String treatmentInstructions, @FutureOrPresent LocalDate followUpDate,
                          @Size(max=2000) String prescriptionInstructions, @Valid List<Medicine> medicines,
                          boolean finalizeRecord) {}
    public record View(Long id, Long appointmentId, Long patientId, String patientName, Long doctorId, String doctorName,
                       String symptoms, String vitalSigns, String diagnosis, String clinicalNotes,
                       String recommendedTests, String treatmentInstructions, LocalDate followUpDate,
                       boolean finalized, Instant createdAt, Instant updatedAt, PrescriptionView prescription) {}
    public record PrescriptionView(Long id, Instant prescriptionDate, String generalInstructions,
                                   PrescriptionStatus status, List<MedicineView> items) {}
    public record MedicineView(Long id, String medicineName, String dosage, String frequency, String duration, String instructions) {}
}
