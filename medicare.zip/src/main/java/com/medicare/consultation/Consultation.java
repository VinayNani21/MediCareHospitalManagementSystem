package com.medicare.consultation;

import com.medicare.appointment.Appointment;
import com.medicare.doctor.Doctor;
import com.medicare.patient.Patient;
import jakarta.persistence.*;
import java.time.Instant;
import java.time.LocalDate;

@Entity
@Table(name = "consultations")
public class Consultation {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @OneToOne(optional = false) @JoinColumn(nullable = false, unique = true) private Appointment appointment;
    @ManyToOne(optional = false) private Patient patient;
    @ManyToOne(optional = false) private Doctor doctor;
    @Column(length = 2000) private String symptoms;
    @Column(length = 1000) private String vitalSigns;
    @Column(length = 2000) private String diagnosis;
    @Column(length = 5000) private String clinicalNotes;
    @Column(length = 2000) private String recommendedTests;
    @Column(length = 2000) private String treatmentInstructions;
    private LocalDate followUpDate;
    @Column(nullable = false) private boolean finalized;
    @Column(nullable = false, updatable = false) private Instant createdAt = Instant.now();
    @Column(nullable = false) private Instant updatedAt = Instant.now();
    protected Consultation() {}
    public Consultation(Appointment appointment) {
        this.appointment = appointment; this.patient = appointment.getPatient(); this.doctor = appointment.getDoctor();
    }
    @PreUpdate void touch() { updatedAt = Instant.now(); }
    public Long getId() { return id; }
    public Appointment getAppointment() { return appointment; }
    public Patient getPatient() { return patient; }
    public Doctor getDoctor() { return doctor; }
    public String getSymptoms() { return symptoms; }
    public void setSymptoms(String value) { symptoms = value; }
    public String getVitalSigns() { return vitalSigns; }
    public void setVitalSigns(String value) { vitalSigns = value; }
    public String getDiagnosis() { return diagnosis; }
    public void setDiagnosis(String value) { diagnosis = value; }
    public String getClinicalNotes() { return clinicalNotes; }
    public void setClinicalNotes(String value) { clinicalNotes = value; }
    public String getRecommendedTests() { return recommendedTests; }
    public void setRecommendedTests(String value) { recommendedTests = value; }
    public String getTreatmentInstructions() { return treatmentInstructions; }
    public void setTreatmentInstructions(String value) { treatmentInstructions = value; }
    public LocalDate getFollowUpDate() { return followUpDate; }
    public void setFollowUpDate(LocalDate value) { followUpDate = value; }
    public boolean isFinalized() { return finalized; }
    public void setFinalized(boolean finalized) { this.finalized = finalized; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
}
