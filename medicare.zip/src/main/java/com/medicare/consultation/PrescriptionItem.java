package com.medicare.consultation;

import jakarta.persistence.*;

@Entity
@Table(name = "prescription_items")
public class PrescriptionItem {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(optional = false) private Prescription prescription;
    @Column(nullable = false, length = 150) private String medicineName;
    @Column(nullable = false, length = 100) private String dosage;
    @Column(nullable = false, length = 100) private String frequency;
    @Column(nullable = false, length = 100) private String duration;
    @Column(length = 500) private String instructions;
    protected PrescriptionItem() {}
    public PrescriptionItem(Prescription prescription, String name, String dosage, String frequency, String duration, String instructions) {
        this.prescription = prescription; this.medicineName = name; this.dosage = dosage;
        this.frequency = frequency; this.duration = duration; this.instructions = instructions;
    }
    public Long getId() { return id; }
    public String getMedicineName() { return medicineName; }
    public String getDosage() { return dosage; }
    public String getFrequency() { return frequency; }
    public String getDuration() { return duration; }
    public String getInstructions() { return instructions; }
}
