package com.medicare.auth;

import com.medicare.common.DomainException;
import com.medicare.common.AuditService;
import com.medicare.patient.Patient;
import com.medicare.patient.PatientRepository;
import com.medicare.security.JwtService;
import com.medicare.user.Role;
import com.medicare.user.User;
import com.medicare.user.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.time.Instant;
import java.util.Map;

@Service
public class AuthService {
    private final UserRepository users;
    private final PatientRepository patients;
    private final PasswordEncoder encoder;
    private final JwtService jwt;
    private final AuditService audit;
    private final Map<String, ResetToken> resetTokens = new ConcurrentHashMap<>();

    public AuthService(UserRepository users, PatientRepository patients, PasswordEncoder encoder, JwtService jwt, AuditService audit) {
        this.users = users; this.patients = patients; this.encoder = encoder; this.jwt = jwt; this.audit = audit;
    }

    @Transactional
    public AuthDtos.AuthResponse register(AuthDtos.RegisterRequest request) {
        if (users.existsByEmailIgnoreCase(request.email())) throw new DomainException(HttpStatus.CONFLICT, "Email is already registered.");
        User user = users.save(new User(request.fullName(), request.email(), encoder.encode(request.password()), request.phone(), Role.PATIENT));
        patients.save(new Patient(user, "MRN-" + UUID.randomUUID().toString().substring(0, 12).toUpperCase()));
        audit.record(user.getEmail(), "PATIENT_REGISTERED", "userId=" + user.getId());
        return response(user);
    }

    public AuthDtos.AuthResponse login(AuthDtos.LoginRequest request) {
        User user = users.findByEmailIgnoreCase(request.email())
                .orElseThrow(() -> new DomainException(HttpStatus.UNAUTHORIZED, "Invalid email or password."));
        if (!user.isActive() || !encoder.matches(request.password(), user.getPasswordHash()))
            throw new DomainException(HttpStatus.UNAUTHORIZED, "Invalid email or password.");
        return response(user);
    }

    public String requestReset(String email) {
        users.findByEmailIgnoreCase(email).filter(User::isActive).ifPresent(user -> {
            String token = UUID.randomUUID().toString();
            resetTokens.put(token, new ResetToken(user.getId(), Instant.now().plusSeconds(1800)));
            System.getLogger(AuthService.class.getName()).log(System.Logger.Level.INFO,
                    "Mock password reset delivery queued for account {0}; token delivery is disabled in local configuration.", user.getEmail());
        });
        return "If an active account exists, password reset instructions will be sent.";
    }

    @Transactional
    public void completeReset(String token, String newPassword) {
        ResetToken reset = resetTokens.remove(token);
        if (reset == null || reset.expiresAt().isBefore(Instant.now()))
            throw new DomainException(HttpStatus.BAD_REQUEST, "Password reset token is invalid or expired.");
        User user = users.findById(reset.userId()).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Account not found."));
        user.setPasswordHash(encoder.encode(newPassword));
        users.save(user);
    }

    private AuthDtos.AuthResponse response(User user) {
        return new AuthDtos.AuthResponse(jwt.generate(user), "Bearer",
                new AuthDtos.UserView(user.getId(), user.getFullName(), user.getEmail(), user.getPhone(), user.getRole(), user.isActive()));
    }
    private record ResetToken(Long userId, Instant expiresAt) {}
}
