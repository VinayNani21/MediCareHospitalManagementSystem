package com.medicare.auth;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;
    public AuthController(AuthService auth) { this.auth = auth; }
    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public AuthDtos.AuthResponse register(@Valid @RequestBody AuthDtos.RegisterRequest request) { return auth.register(request); }
    @PostMapping("/login")
    public AuthDtos.AuthResponse login(@Valid @RequestBody AuthDtos.LoginRequest request) { return auth.login(request); }
    @PostMapping("/password-reset")
    public Map<String, String> reset(@Valid @RequestBody AuthDtos.ResetRequest request) {
        return Map.of("message", auth.requestReset(request.email()));
    }
    @PostMapping("/password-reset/complete")
    public Map<String, String> completeReset(@Valid @RequestBody AuthDtos.ResetCompleteRequest request) {
        auth.completeReset(request.token(), request.newPassword());
        return Map.of("message", "Password updated.");
    }
    @PostMapping("/logout")
    public Map<String, String> logout() { return Map.of("message", "Remove the bearer token from the client to log out."); }
}
