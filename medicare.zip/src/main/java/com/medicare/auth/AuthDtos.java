package com.medicare.auth;

import com.medicare.user.Role;
import jakarta.validation.constraints.*;

public final class AuthDtos {
    private AuthDtos() {}
    public record RegisterRequest(@NotBlank @Size(max = 120) String fullName,
                                 @NotBlank @Email @Size(max = 190) String email,
                                 @NotBlank @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d).{10,72}$",
                                         message = "Password must be 10-72 characters and include a letter and a digit.")
                                 String password,
                                 @NotBlank @Pattern(regexp = "^[+0-9() .-]{7,30}$") String phone) {}
    public record LoginRequest(@NotBlank @Email String email, @NotBlank String password) {}
    public record AuthResponse(String token, String tokenType, UserView user) {}
    public record UserView(Long id, String fullName, String email, String phone, Role role, boolean active) {}
    public record ProfileUpdateRequest(@NotBlank @Size(max=120) String fullName,
                                       @NotBlank @Email @Size(max=190) String email,
                                       @Pattern(regexp = "^[+0-9() .-]{7,30}$") String phone) {}
    public record ResetRequest(@NotBlank @Email String email) {}
    public record ResetCompleteRequest(@NotBlank String token, @NotBlank @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d).{10,72}$") String newPassword) {}
}
