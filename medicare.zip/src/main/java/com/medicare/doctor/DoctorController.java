package com.medicare.doctor;

import com.medicare.common.CurrentUser;
import com.medicare.common.DomainException;
import com.medicare.department.Department;
import com.medicare.department.DepartmentRepository;
import com.medicare.user.Role;
import com.medicare.user.User;
import com.medicare.user.UserRepository;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@RestController
@RequestMapping("/api/doctors")
public class DoctorController {
    private final DoctorRepository doctors;
    private final DepartmentRepository departments;
    private final UserRepository users;
    private final CurrentUser current;
    private final PasswordEncoder encoder;
    public DoctorController(DoctorRepository doctors, DepartmentRepository departments, UserRepository users,
                            CurrentUser current, PasswordEncoder encoder) {
        this.doctors = doctors; this.departments = departments; this.users = users; this.current = current; this.encoder = encoder;
    }

    @GetMapping
    public Page<DoctorDtos.View> list(@RequestParam(required=false) String search,
            @RequestParam(required=false) Long departmentId, @RequestParam(defaultValue="0") int page,
            @RequestParam(defaultValue="12") int size, @RequestParam(defaultValue="fullName") String sort) {
        if (page < 0 || size < 1 || size > 100 || !java.util.Set.of("fullName", "consultationFee", "yearsOfExperience").contains(sort))
            throw new DomainException(HttpStatus.BAD_REQUEST, "Invalid pagination or sort parameter.");
        String term = search == null || search.isBlank() ? null : search.trim();
        String sortProperty = sort.equals("fullName") ? "user.fullName" : sort;
        return doctors.search(term, departmentId, PageRequest.of(page, size, Sort.by(sortProperty))).map(this::view);
    }

    @GetMapping("/{id}")
    public DoctorDtos.View get(@PathVariable Long id) {
        return view(doctors.findById(id).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Doctor not found.")));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('ADMIN')")
    public DoctorDtos.View create(@Valid @RequestBody DoctorDtos.Create request) {
        if (users.existsByEmailIgnoreCase(request.email())) throw new DomainException(HttpStatus.CONFLICT, "Email is already registered.");
        Department department = department(request.departmentId());
        User user = users.save(new User(request.fullName(), request.email(), encoder.encode(request.password()), request.phone(), Role.DOCTOR));
        Doctor d = new Doctor(user, department, request.specialization(), request.qualification(),
                request.consultationFee(), request.yearsOfExperience());
        d.setBiography(request.biography());
        return view(doctors.save(d));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public DoctorDtos.View update(@PathVariable Long id, @Valid @RequestBody DoctorDtos.Update request) {
        Doctor d = doctor(id);
        d.setSpecialization(request.specialization()); d.setQualification(request.qualification());
        d.setDepartment(department(request.departmentId())); d.setConsultationFee(request.consultationFee());
        d.setYearsOfExperience(request.yearsOfExperience()); d.setBiography(request.biography()); d.setAvailable(request.available());
        return view(doctors.save(d));
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("hasRole('ADMIN')")
    public void deactivate(@PathVariable Long id) {
        Doctor d = doctor(id); d.getUser().setActive(false); users.save(d.getUser());
    }

    @PutMapping("/me")
    @PreAuthorize("hasRole('DOCTOR')")
    public DoctorDtos.View updateOwn(Authentication authentication, @Valid @RequestBody DoctorDtos.ProfileUpdate request) {
        User user = current.require(authentication);
        Doctor doctor = doctors.findByUserId(user.getId()).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Doctor profile not found."));
        user.setFullName(request.fullName()); user.setPhone(request.phone()); users.save(user);
        doctor.setQualification(request.qualification()); doctor.setBiography(request.biography());
        return view(doctors.save(doctor));
    }

    @GetMapping("/me")
    @PreAuthorize("hasRole('DOCTOR')")
    public DoctorDtos.View ownProfile(Authentication authentication) {
        User user = current.require(authentication);
        return doctors.findByUserId(user.getId()).map(this::view)
                .orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Doctor profile not found."));
    }

    private Doctor doctor(Long id) { return doctors.findById(id).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Doctor not found.")); }
    private Department department(Long id) { return departments.findById(id).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Department not found.")); }
    private DoctorDtos.View view(Doctor d) {
        return new DoctorDtos.View(d.getId(), d.getUser().getId(), d.getUser().getFullName(), d.getUser().getEmail(),
                d.getUser().getPhone(), d.getSpecialization(), d.getQualification(), d.getDepartment().getId(),
                d.getDepartment().getName(), d.getConsultationFee(), d.getBiography(), d.getYearsOfExperience(),
                d.isAvailable(), d.getUser().isActive());
    }
}
