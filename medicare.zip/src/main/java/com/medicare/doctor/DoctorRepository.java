package com.medicare.doctor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.Optional;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {
    Optional<Doctor> findByUserId(Long userId);
    long countByDepartmentId(Long departmentId);
    @Query("""
        select d from Doctor d join d.user u join d.department dep
        where u.active = true and dep.active = true
          and (:search is null or lower(u.fullName) like lower(concat('%', :search, '%'))
          or lower(d.specialization) like lower(concat('%', :search, '%')))
          and (:departmentId is null or dep.id = :departmentId)
        """)
    Page<Doctor> search(@Param("search") String search, @Param("departmentId") Long departmentId, Pageable pageable);
}
