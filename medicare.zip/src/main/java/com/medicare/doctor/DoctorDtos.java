package com.medicare.doctor;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public final class DoctorDtos {
    private DoctorDtos() {}
    public record View(Long id, Long userId, String fullName, String email, String phone, String specialization,
                       String qualification, Long departmentId, String departmentName, BigDecimal consultationFee,
                       String biography, int yearsOfExperience, boolean available, boolean active) {}
    public record Create(@NotBlank @Size(max=120) String fullName, @NotBlank @Email String email,
                         @NotBlank @Pattern(regexp="^[+0-9() .-]{7,30}$") String phone,
                         @NotBlank @Pattern(regexp="^(?=.*[A-Za-z])(?=.*\\d).{10,72}$") String password,
                         @NotBlank @Size(max=100) String specialization, @Size(max=150) String qualification,
                         @NotNull @Positive Long departmentId, @NotNull @DecimalMin("0.0") BigDecimal consultationFee,
                         @Min(0) @Max(80) int yearsOfExperience, @Size(max=2000) String biography) {}
    public record Update(@NotBlank @Size(max=100) String specialization, @Size(max=150) String qualification,
                         @NotNull @Positive Long departmentId, @NotNull @DecimalMin("0.0") BigDecimal consultationFee,
                         @Min(0) @Max(80) int yearsOfExperience, @Size(max=2000) String biography,
                         boolean available) {}
    public record ProfileUpdate(@NotBlank @Size(max=120) String fullName,
                                @NotBlank @Pattern(regexp="^[+0-9() .-]{7,30}$") String phone,
                                @Size(max=150) String qualification, @Size(max=2000) String biography) {}
}
