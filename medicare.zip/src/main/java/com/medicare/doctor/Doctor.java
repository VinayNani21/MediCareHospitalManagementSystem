package com.medicare.doctor;

import com.medicare.department.Department;
import com.medicare.user.User;
import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "doctors")
public class Doctor {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @OneToOne(optional = false) @JoinColumn(nullable = false, unique = true) private User user;
    @ManyToOne(optional = false) private Department department;
    @Column(nullable = false, length = 100) private String specialization;
    @Column(length = 150) private String qualification;
    @Column(length = 2000) private String biography;
    @Column(nullable = false, precision = 10, scale = 2) private BigDecimal consultationFee = BigDecimal.ZERO;
    @Column(nullable = false) private int yearsOfExperience;
    @Column(nullable = false) private boolean available = true;
    protected Doctor() {}
    public Doctor(User user, Department department, String specialization, String qualification, BigDecimal fee, int experience) {
        this.user = user; this.department = department; this.specialization = specialization;
        this.qualification = qualification; this.consultationFee = fee; this.yearsOfExperience = experience;
    }
    public Long getId() { return id; }
    public User getUser() { return user; }
    public Department getDepartment() { return department; }
    public void setDepartment(Department department) { this.department = department; }
    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }
    public String getQualification() { return qualification; }
    public void setQualification(String qualification) { this.qualification = qualification; }
    public String getBiography() { return biography; }
    public void setBiography(String biography) { this.biography = biography; }
    public BigDecimal getConsultationFee() { return consultationFee; }
    public void setConsultationFee(BigDecimal consultationFee) { this.consultationFee = consultationFee; }
    public int getYearsOfExperience() { return yearsOfExperience; }
    public void setYearsOfExperience(int yearsOfExperience) { this.yearsOfExperience = yearsOfExperience; }
    public boolean isAvailable() { return available && user.isActive() && department.isActive(); }
    public void setAvailable(boolean available) { this.available = available; }
}
