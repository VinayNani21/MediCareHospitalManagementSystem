package com.medicare.patient;

import jakarta.validation.constraints.*;
import java.time.Instant;
import java.time.LocalDate;

public final class PatientDtos {
    private PatientDtos() {}
    public record Profile(Long id, String fullName, String email, String phone, LocalDate dateOfBirth,
                          Gender gender, String address, String emergencyContact, String bloodGroup,
                          String allergies, String medicalConditions, String medicalRecordNumber,
                          boolean active, Instant createdAt) {}
    public record UpdateProfile(@Past LocalDate dateOfBirth, Gender gender,
                                @Size(max=500) String address, @Size(max=120) String emergencyContact,
                                @Size(max=20) String bloodGroup, @Size(max=1000) String allergies,
                                @Size(max=1000) String medicalConditions) {}
}
