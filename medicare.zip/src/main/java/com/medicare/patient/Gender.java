package com.medicare.patient;

public enum Gender { FEMALE, MALE, NON_BINARY, PREFER_NOT_TO_SAY }
