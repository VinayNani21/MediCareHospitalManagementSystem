package com.medicare.patient;

import com.medicare.user.User;
import jakarta.persistence.*;
import java.time.Instant;
import java.time.LocalDate;

@Entity
@Table(name = "patients", indexes = @Index(name = "idx_patient_mrn", columnList = "medical_record_number", unique = true))
public class Patient {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @OneToOne(optional = false) @JoinColumn(nullable = false, unique = true) private User user;
    @Column(name = "medical_record_number", nullable = false, unique = true, length = 32) private String medicalRecordNumber;
    private LocalDate dateOfBirth;
    @Enumerated(EnumType.STRING) private Gender gender;
    @Column(length = 500) private String address;
    @Column(length = 120) private String emergencyContact;
    @Column(length = 20) private String bloodGroup;
    @Column(length = 1000) private String allergies;
    @Column(length = 1000) private String medicalConditions;
    @Column(nullable = false, updatable = false) private Instant createdAt = Instant.now();

    protected Patient() {}
    public Patient(User user, String medicalRecordNumber) { this.user = user; this.medicalRecordNumber = medicalRecordNumber; }
    public Long getId() { return id; }
    public User getUser() { return user; }
    public String getMedicalRecordNumber() { return medicalRecordNumber; }
    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }
    public Gender getGender() { return gender; }
    public void setGender(Gender gender) { this.gender = gender; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getEmergencyContact() { return emergencyContact; }
    public void setEmergencyContact(String emergencyContact) { this.emergencyContact = emergencyContact; }
    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }
    public String getAllergies() { return allergies; }
    public void setAllergies(String allergies) { this.allergies = allergies; }
    public String getMedicalConditions() { return medicalConditions; }
    public void setMedicalConditions(String medicalConditions) { this.medicalConditions = medicalConditions; }
    public Instant getCreatedAt() { return createdAt; }
}
