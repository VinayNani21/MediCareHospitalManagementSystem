package com.medicare.patient;

import com.medicare.common.CurrentUser;
import com.medicare.common.DomainException;
import com.medicare.appointment.AppointmentRepository;
import com.medicare.doctor.DoctorRepository;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/patients")
public class PatientController {
    private final PatientRepository patients;
    private final CurrentUser current;
    private final AppointmentRepository appointments;
    private final DoctorRepository doctors;
    public PatientController(PatientRepository patients, CurrentUser current, AppointmentRepository appointments, DoctorRepository doctors) {
        this.patients = patients; this.current = current; this.appointments = appointments; this.doctors = doctors;
    }

    @GetMapping("/me")
    @PreAuthorize("hasRole('PATIENT')")
    public PatientDtos.Profile me(Authentication auth) { return profile(auth); }

    @PutMapping("/me")
    @PreAuthorize("hasRole('PATIENT')")
    public PatientDtos.Profile update(Authentication auth, @Valid @RequestBody PatientDtos.UpdateProfile request) {
        Patient patient = own(auth);
        patient.setDateOfBirth(request.dateOfBirth()); patient.setGender(request.gender());
        patient.setAddress(request.address()); patient.setEmergencyContact(request.emergencyContact());
        patient.setBloodGroup(request.bloodGroup()); patient.setAllergies(request.allergies());
        patient.setMedicalConditions(request.medicalConditions());
        return view(patients.save(patient));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('RECEPTIONIST','ADMIN')")
    public Page<PatientDtos.Profile> search(@RequestParam(required=false) String search,
                    @RequestParam(defaultValue="0") int page, @RequestParam(defaultValue="20") int size) {
        if (page < 0 || size < 1 || size > 100) throw new DomainException(HttpStatus.BAD_REQUEST, "Invalid pagination parameters.");
        String term = search == null || search.isBlank() ? null : search.trim();
        return patients.search(term, PageRequest.of(page, size)).map(this::view);
    }

    @GetMapping("/{id}/medical-history")
    @PreAuthorize("hasAnyRole('DOCTOR','ADMIN')")
    public PatientDtos.Profile medicalHistory(Authentication authentication, @PathVariable Long id) {
        var actor = current.require(authentication);
        Patient patient = patients.findById(id).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Patient not found."));
        if (actor.getRole() == com.medicare.user.Role.DOCTOR) {
            var doctor = doctors.findByUserId(actor.getId())
                    .orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Doctor profile not found."));
            if (!appointments.existsByDoctorIdAndPatientId(doctor.getId(), patient.getId()))
                throw new DomainException(HttpStatus.FORBIDDEN, "Patient does not have an appointment with this doctor.");
        }
        return view(patient);
    }

    public PatientDtos.Profile profile(Authentication auth) { return view(own(auth)); }

    public Patient requireOwn(Authentication auth) { return own(auth); }

    private Patient own(Authentication auth) {
        return patients.findByUserId(current.require(auth).getId())
                .orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Patient profile not found."));
    }

    private PatientDtos.Profile view(Patient p) {
        var user = p.getUser();
        return new PatientDtos.Profile(p.getId(), user.getFullName(), user.getEmail(), user.getPhone(), p.getDateOfBirth(),
                p.getGender(), p.getAddress(), p.getEmergencyContact(), p.getBloodGroup(), p.getAllergies(),
                p.getMedicalConditions(), p.getMedicalRecordNumber(), user.isActive(), p.getCreatedAt());
    }
}
