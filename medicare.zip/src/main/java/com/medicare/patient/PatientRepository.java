package com.medicare.patient;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import jakarta.persistence.LockModeType;
import java.util.Optional;

public interface PatientRepository extends JpaRepository<Patient, Long> {
    Optional<Patient> findByUserId(Long userId);
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select p from Patient p where p.id = :id")
    Optional<Patient> lockPatient(@Param("id") Long id);
    @Query("""
        select p from Patient p join p.user u
        where :search is null or lower(u.fullName) like lower(concat('%', :search, '%'))
          or lower(u.email) like lower(concat('%', :search, '%'))
          or lower(p.medicalRecordNumber) like lower(concat('%', :search, '%'))
        """)
    Page<Patient> search(@Param("search") String search, Pageable pageable);
}
