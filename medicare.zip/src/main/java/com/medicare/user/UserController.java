package com.medicare.user;

import com.medicare.auth.AuthDtos;
import com.medicare.common.CurrentUser;
import com.medicare.common.DomainException;
import com.medicare.common.AuditService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {
    private final UserRepository users;
    private final CurrentUser current;
    private final AuditService audit;
    public UserController(UserRepository users, CurrentUser current, AuditService audit) {
        this.users = users; this.current = current; this.audit = audit;
    }

    @GetMapping("/me")
    public AuthDtos.UserView me(Authentication auth) { return view(current.require(auth)); }

    @PutMapping("/me")
    public AuthDtos.UserView update(Authentication auth, @Valid @RequestBody AuthDtos.ProfileUpdateRequest request) {
        User user = current.require(auth);
        if (!user.getEmail().equalsIgnoreCase(request.email()) && users.existsByEmailIgnoreCase(request.email()))
            throw new DomainException(HttpStatus.CONFLICT, "Email is already in use.");
        user.setFullName(request.fullName()); user.setEmail(request.email()); user.setPhone(request.phone());
        return view(users.save(user));
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Page<AuthDtos.UserView> list(@RequestParam(required=false) Role role,
                    @RequestParam(defaultValue="0") int page, @RequestParam(defaultValue="20") int size) {
        if (page < 0 || size < 1 || size > 100) throw new DomainException(HttpStatus.BAD_REQUEST, "Invalid pagination parameters.");
        PageRequest pageable = PageRequest.of(page, size);
        Page<User> result = role == null ? users.findAll(pageable) : users.findByRole(role, pageable);
        return result.map(this::view);
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    public AuthDtos.UserView status(Authentication authentication, @PathVariable Long id, @RequestParam boolean active) {
        User user = users.findById(id).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "User not found."));
        user.setActive(active);
        User updated = users.save(user);
        audit.record(current.require(authentication).getEmail(), "USER_STATUS_CHANGED", "userId=" + id + ",active=" + active);
        return view(updated);
    }

    private AuthDtos.UserView view(User u) {
        return new AuthDtos.UserView(u.getId(), u.getFullName(), u.getEmail(), u.getPhone(), u.getRole(), u.isActive());
    }
}
