package com.medicare.user;

public enum Role { PATIENT, DOCTOR, RECEPTIONIST, ADMIN }
