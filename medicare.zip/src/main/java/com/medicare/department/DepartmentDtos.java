package com.medicare.department;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public final class DepartmentDtos {
    private DepartmentDtos() {}
    public record View(Long id, String name, String description, boolean active) {}
    public record Request(@NotBlank @Size(max=100) String name, @Size(max=500) String description, boolean active) {}
}
