package com.medicare.department;

import com.medicare.common.DomainException;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/departments")
public class DepartmentController {
    private final DepartmentRepository departments;
    public DepartmentController(DepartmentRepository departments) { this.departments = departments; }
    @GetMapping
    public List<DepartmentDtos.View> list() {
        return departments.findAll().stream().filter(Department::isActive).map(this::view).toList();
    }
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('ADMIN')")
    public DepartmentDtos.View create(@Valid @RequestBody DepartmentDtos.Request request) {
        return view(departments.save(new Department(request.name(), request.description())));
    }
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public DepartmentDtos.View update(@PathVariable Long id, @Valid @RequestBody DepartmentDtos.Request request) {
        Department d = departments.findById(id).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Department not found."));
        d.setName(request.name()); d.setDescription(request.description()); d.setActive(request.active());
        return view(departments.save(d));
    }
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("hasRole('ADMIN')")
    public void deactivate(@PathVariable Long id) {
        Department d = departments.findById(id).orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Department not found."));
        d.setActive(false); departments.save(d);
    }
    private DepartmentDtos.View view(Department d) { return new DepartmentDtos.View(d.getId(), d.getName(), d.getDescription(), d.isActive()); }
}
