package com.medicare.notification;

import com.medicare.common.CurrentUser;
import com.medicare.common.DomainException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {
    private final NotificationRepository notifications;
    private final CurrentUser current;
    public NotificationController(NotificationRepository notifications, CurrentUser current) {
        this.notifications = notifications; this.current = current;
    }

    @GetMapping
    public Page<View> list(Authentication authentication, @RequestParam(defaultValue="0") int page,
                           @RequestParam(defaultValue="20") int size) {
        if (page < 0 || size < 1 || size > 100) throw new DomainException(HttpStatus.BAD_REQUEST, "Invalid pagination parameters.");
        Long userId = current.require(authentication).getId();
        return notifications.findByUserIdOrderByCreatedAtDesc(userId, PageRequest.of(page, size)).map(this::view);
    }
    @GetMapping("/unread-count")
    public java.util.Map<String, Long> unreadCount(Authentication authentication) {
        Long userId = current.require(authentication).getId();
        return java.util.Map.of("count", notifications.countByUserIdAndReadFalse(userId));
    }
    @PatchMapping("/{id}/read")
    public View read(Authentication authentication, @PathVariable Long id) {
        Long userId = current.require(authentication).getId();
        Notification n = notifications.findByIdAndUserId(id, userId)
                .orElseThrow(() -> new DomainException(HttpStatus.NOT_FOUND, "Notification not found."));
        n.setRead(true);
        return view(notifications.save(n));
    }
    private View view(Notification n) { return new View(n.getId(), n.getTitle(), n.getMessage(), n.isRead(), n.getCreatedAt()); }
    public record View(Long id, String title, String message, boolean read, java.time.Instant createdAt) {}
}
