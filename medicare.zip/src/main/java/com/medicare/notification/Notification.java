package com.medicare.notification;

import com.medicare.user.User;
import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "notifications", indexes = @Index(name = "idx_notification_user_read", columnList = "user_id,is_read"))
public class Notification {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(optional = false) private User user;
    @Column(nullable = false, length = 140) private String title;
    @Column(nullable = false, length = 1000) private String message;
    @Column(name = "is_read", nullable = false) private boolean read;
    @Column(nullable = false, updatable = false) private Instant createdAt = Instant.now();
    protected Notification() {}
    public Notification(User user, String title, String message) { this.user = user; this.title = title; this.message = message; }
    public Long getId() { return id; }
    public User getUser() { return user; }
    public String getTitle() { return title; }
    public String getMessage() { return message; }
    public boolean isRead() { return read; }
    public void setRead(boolean read) { this.read = read; }
    public Instant getCreatedAt() { return createdAt; }
}
