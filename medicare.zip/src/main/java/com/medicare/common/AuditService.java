package com.medicare.common;

import org.springframework.stereotype.Service;

@Service
public class AuditService {
    private final AuditLogRepository logs;
    public AuditService(AuditLogRepository logs) { this.logs = logs; }
    public void record(String actor, String action, String details) {
        logs.save(new AuditLog(actor, action, details));
    }
}
