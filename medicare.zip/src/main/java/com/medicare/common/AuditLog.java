package com.medicare.common;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "audit_logs", indexes = @Index(name = "idx_audit_created", columnList = "created_at"))
public class AuditLog {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(length = 190) private String actorEmail;
    @Column(nullable = false, length = 80) private String action;
    @Column(length = 500) private String details;
    @Column(name = "created_at", nullable = false, updatable = false) private Instant createdAt = Instant.now();
    protected AuditLog() {}
    public AuditLog(String actorEmail, String action, String details) {
        this.actorEmail = actorEmail; this.action = action; this.details = details;
    }
}
