package com.medicare.common;

import com.medicare.user.User;
import com.medicare.user.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

@Component
public class CurrentUser {
    private final UserRepository users;
    public CurrentUser(UserRepository users) { this.users = users; }
    public User require(Authentication authentication) {
        if (authentication == null) throw new DomainException(HttpStatus.UNAUTHORIZED, "Authentication is required.");
        return users.findByEmailIgnoreCase(authentication.getName())
                .orElseThrow(() -> new DomainException(HttpStatus.UNAUTHORIZED, "Account not found."));
    }
}
