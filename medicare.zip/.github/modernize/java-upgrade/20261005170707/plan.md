# Upgrade Plan: medicare-hospital (20261005170707)

- **Generated**: 2026-10-05 22:37 IST
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

> Version control is unavailable in this workspace; upgrade changes will remain uncommitted in the working directory.

## Available Tools

**JDKs**
- JDK 17: not available (baseline will be skipped)
- JDK 25: **<TO_BE_INSTALLED>** (required for target compilation and test validation)

**Build Tools**
- Maven 3.9.15: `C:\Users\Acer\.maven\maven-3.9.15\expanded\apache-maven-3.9.15\bin`
- Maven Wrapper: not present

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: N/A (version control unavailable)
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java runtime and compilation target: 25 (latest LTS)

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| --------------------- | ------- | ---------------------- | ---------------- |
| Java | 17 | 25 | User requested Java 25 LTS |
| Spring Boot | 3.3.5 | 3.5.16 | Spring Framework 6.1's bundled ASM cannot scan Java 25 class files |
| springdoc-openapi | 2.6.0 | 2.8.17 | Align with Spring Boot 3.5 / Spring Framework 6.2 |
| Maven | 3.9.15 | 3.9.15 | Available and compatible; no wrapper present |
| maven-compiler-plugin | Inherited from Spring Boot parent 3.3.5 | 3.11.0 | Java 25 compilation must be verified; plugin version is inherited |
| maven-surefire-plugin | Inherited from Spring Boot parent 3.3.5 | 3.0.0 | Java 25 test execution must be verified; plugin version is inherited |

## Derived Upgrades

- Install JDK 25 because it is not currently installed and is required for target-runtime validation.
- Update the Maven `java.version` property and user-facing Java requirements to 25.
- Upgrade Spring Boot to 3.5.16 and springdoc-openapi to 2.8.17: the existing Spring Framework 6.1.14 bundled ASM rejects Java 25 class-file version 69 during test startup; Boot 3.5.16 manages Spring Framework 6.2.19.
- No Kotlin, Gradle, or Maven wrapper is present; no related updates are needed.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| `pom.xml` | `java.version` | 17 | upgrade | 25 | Set the compiler/runtime target requested by the user |
| `pom.xml` | `spring-boot-starter-parent` | 3.3.5 | upgrade | 3.5.16 | Provides Spring Framework 6.2.19, which can parse Java 25 class files |
| `pom.xml` | `springdoc-openapi-starter-webmvc-ui` | 2.6.0 | upgrade | 2.8.17 | Align the OpenAPI integration with Spring Boot 3.5 |

### Source Code Changes

No Java source changes are indicated by the compatibility scan: no JDK-internal APIs, reflective access to JDK internals, or removed runtime APIs were found.

### Configuration Changes

No application runtime configuration changes are required.

### CI/CD Changes

No CI/CD, container, or pipeline files with Java-version pins were found.

### Documentation Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| `README.md` | Overview and Requirements | Java 17+ | Update minimum/runtime requirement to Java 25 | Keep documented build/runtime requirements aligned with the target |
| `new` | Backend technology requirements | Java 17 or later | Update minimum/runtime requirement to Java 25 | Keep the project requirements brief aligned with the build target |

### Risks & Warnings

- **Spring Framework class-file support**: Spring Framework 6.1.14 cannot parse Java 25 class-file version 69. **Mitigation**: Upgrade Spring Boot to 3.5.16 (Spring Framework 6.2.19) and springdoc-openapi to 2.8.17, then rerun clean compilation and all tests on JDK 25.
- **Baseline unavailable**: JDK 17 is not installed, so a pre-upgrade baseline cannot be run. **Mitigation**: Record the baseline step as skipped and require successful clean test compilation and tests on JDK 25.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: JDK 25 is required to verify compilation and execution on the requested target.
  - **Changes to Make**: Install JDK 25; use the existing Maven 3.9.15 installation.
  - **Verification**: `appmod-list-jdks`, JDK 25; JDK 25 is listed and its installation path exists.
- Step 2: Setup Baseline
  - **Rationale**: A pre-upgrade result is useful for comparison, but the current JDK 17 is unavailable.
  - **Changes to Make**: None; skip baseline compilation and tests because JDK 17 is not installed.
  - **Verification**: Confirm JDK 17 absence; mark baseline skipped.
- Step 3: Set Java 25 Target
  - **Rationale**: Update the Maven compiler target and documentation together so builds and setup guidance agree.
  - **Changes to Make**: Apply the `pom.xml`, `README.md`, and `new` changes listed in Impact Analysis.
  - **Verification**: `mvn clean test-compile -q` with JDK 25; production and test sources compile.
- Step 4: Upgrade Java 25-Compatible Spring Dependencies
  - **Rationale**: The existing Spring Framework's ASM fails to scan Java 25 class files during test startup.
  - **Changes to Make**: Upgrade Spring Boot and springdoc-openapi as listed in Dependency Changes.
  - **Verification**: `mvn clean test-compile -q` with JDK 25; production and test sources compile.
- Step 5: CVE Validation & Fix
  - **Rationale**: Check direct dependencies for known vulnerabilities after the dependency/build state is finalized.
  - **Changes to Make**: Scan resolved direct dependencies and apply fixes only if actionable CVEs are reported.
  - **Verification**: Maven dependency listing and CVE scan; if fixes are required, rerun target-JDK compilation and rescan.
- Step 6: Final Validation
  - **Rationale**: Confirm the Java 25 goal, clean compilation, and all available tests.
  - **Changes to Make**: Resolve any Java 25-specific build or test failures, including necessary minimal compatibility updates.
  - **Verification**: `mvn clean test-compile -q` and `mvn clean test -q` with JDK 25; compilation succeeds and all tests pass.
