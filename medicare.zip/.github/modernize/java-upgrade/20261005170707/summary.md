# Java Runtime Upgrade Summary: medicare-hospital

- **Session ID**: 20261005170707
- **Completed**: 2026-10-05
- **Target**: Java 25 LTS
- **Result**: Successful

## Changes

- Set the Maven Java compilation/runtime target to 25.
- Upgraded Spring Boot from 3.3.5 to 3.5.16 and springdoc-openapi from 2.6.0 to 2.8.17. This was required because the prior Spring Framework/ASM could not scan Java 25 class files.
- Updated the README and project requirements to require JDK 25 or later.
- Installed JDK 25.0.2. A parenthesis-free JDK path alias is used for Maven test forks.

## Validation

- `mvn clean test-compile -q`: passed on JDK 25.
- `mvn clean test -q`: passed; 3 of 3 tests passed.
- `mvn clean verify -Djacoco.skip=false -q`: passed; all 3 tests passed.
- CVE scan: 12 resolved direct dependencies scanned; no known CVEs requiring fixes were reported.
- Coverage: no JaCoCo coverage report is configured in the project.

## Notes and Limitations

- Baseline tests were skipped because JDK 17 was not installed.
- The workspace's existing `target/test-classes` directory has a deny-delete ACL. Clean builds were therefore verified from an isolated copy; the protected directory was left untouched.
- This workspace is not a Git repository, so changes are not committed.
- An already-running application process was left untouched; restart the application with JDK 25 for the running process to use the upgraded runtime.
